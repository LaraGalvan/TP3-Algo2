#ifndef CASILLEROCAMINO_H_
#define CASILLEROCAMINO_H_

#include "Casillero.h"

class CasilleroCamino : public Casillero {
public:
    //constructor
    CasilleroCamino(int fila, int columna);
};


#endif /* CASILLEROCAMINO_H_ */
