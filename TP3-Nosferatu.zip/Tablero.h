#ifndef TP3_NOSFERATU_TABLERO_H
#define TP3_NOSFERATU_TABLERO_H

#include "Arbol.h"
#include "Casillero.h"
#include "LectorArchivo.h"
#include "Humano.h"
#include "Monstruo.h"
#include "ImpresionesPantalla.h"


class Tablero {
private:
    //atributos
    Casillero ***matriz;
    Arbol *diccionario;
    int ancho;
    int alto;
public:

    //PRE: Recibe la referencia del puntero del lector del tablero
    //POST: Se setea el tamaño del tablero, se crea la matriz vacia y se crean los casilleros
    Tablero(LectorArchivo &archivo);


    //PRE: -
    //POST: Devuelve el diccionario
    Arbol* getDiccionario();

    //PRE: -
    //POST: Se crea la matriz vacia
    void crearMatrizVacia();

    //PRE: Recibe una linea del tipo string
    //POST: Se setean los atributos alto y ancho
    void setTamano(const string &linea);

    //PRE: -
    //POST: Se llama al metodo que crea los casilleros
    void crearCasilleros(LectorArchivo &lectorTablero);

    //PRE: Recibe una palabra de tipo string, una fila y una columna
    //POST: Se crea el casillero correspondiente a la palabra pasada por parametro
    void crearCasillero(const string &palabra, int fila, int columna);

    //PRE: Recibe un cuadrante, una fila inicial y final junto a una columna inicial y final
    //POST: Se definen los limites del cuadrante pasado por parametro
    void definirLimitesCuadrantes(int cuadrante, int &filaInicio, int &filaFin, int &columnaInicio, int &columnaFin);

    //PRE: Recibe una fila y una columna de tipo entero
    //POST: Devuelve el puntero del casillero correspondiente a esa posicion
    Casillero *devolverCasillero(int fila, int columna);


    //---------------------

    //PRE: -
    //POST: Se agregan todos los objetos
    void rellenar(LectorArchivo &lector);

    //--------------

    //PRE: -
    //POST: Se muestran por pantalla todos los casilleros
    void mostrar();

    //PRE: -
    //POST: Devuelve el atributo ancho
    int getAncho();

    //PRE: -
    //POST: Devuelve el atributo alto
    int getAlto();

    //---------------------
    //PRE: Recibe una fila y una columna
    //POST: Se elimina el objeto de la matriz y el diccionario de esa posicion
    void eliminarObjeto(int fila, int columna);

    void eliminarItem(int fila, int columna);

    //PRE: Recibe la fila y clumna de un casillero
    //POST: Devuelve true si en ese casillero hay un objeto. False en caso contrario
    bool haySer(int filaCasillero, int columnaCasillero);

    //PRE: Recibe un cuadrante y un objeto de tipo entero
    //POST: Devuelve el valor resultante del método busquedaCuadranteElegido
    bool busquedaPorCuadrante(int cuadrante, int objeto);

    //PRE: Recibe una fila y columna inicial y final junto a un objeto
    //POST: Devuelve true si se encontro al objeto pasado por parametro. False en caso contrario
    bool busquedaCuadranteElegido(int &filaInicio, int &filaFin, int &columnaInicio, int &columnaFinal, int objeto);

    //PRE: Recibe un objeto de tipo entero
    //POST: Devuelve el caracter asociado correspondiente al objeto
    char devolverNombreFichaObjeto(int objeto);

    //PRE: Recibe una fila y columna inicial y final junto al caracter del Objeto
    //POST: Devuelve true si se encontro al objeto. False en caso contrario
    bool busquedaGeneral(int &filaInicio, int &filaFin, int &columnaInicio, int &columnaFinal, char fichaObjeto);

    //PRE: Recibe una fila y columna inicial y final
    //POST: Devuelve true si se encontro el caracter del objeto o personaje buscado
    bool busquedaEspecialHumanos(int &filaInicio, int &filaFinal, int &columnaInicio, int &columnaFinal);

    //PRE:  Recibe una fila y columna inicial y final
    //POST: Devuelve true si se encontro el caracter del objeto o personaje buscado
    bool busquedaEspecialVampiros(int &filaInicio, int &filaFinal, int &columnaInicio, int &columnaFinal);
    //---------------------

    //PRE: Recibe una fila y una columna que representan una posicion en la matriz
    //POST: Devuelve true si en esa posicion de la matriz hay item. False en caso contrario
    bool hayItem(int fila, int columma);

    //PRE: Recibe un nombre del objeto a agregar junto a su posicion, cantidad e id correspondiente
    //POST: Se agrega el objeto a la matriz y al diccionario
    void agregarObjeto(const string& nombre, int fila, int columna, int cantidad, int id);

    //PRE: Recibe la fila y columna de un casillero
    //POST: Devuelve true si hay un objeto en ese casillero
    bool hayObjetoEnCasillero(int fila, int columna);

    //PRE: Recibe la fila y columna de un casillero dentro del tablero
    //POST: Devuelve el objeto que hay dentro de ese casillero, si es que lo tiene sino devuelve null
    Objeto* devolverObjetoEnCasillero(int fila, int columna);

    //PRE:
    //POST: agrega el ser a su nueva ubicacion
    void agregarSer(const string &nombre, int fila, int columna, int cantidad, int id, float vida, float armadura,float fuerza, float energia);


    //PRE: Reciba una fila y columna del tipo entero
    //POST: Se le pide al usuario que ingrese unas coordenadas y las valida
    void ingresarCoordenadas(int &fila, int &columna);


    //PRE:
    //POST:devuelve true si hay alguien para atacar o defender
    bool hayQuienAtacarDefender(Ser* atacante, Accion &error, int filaElegida, int columnaElegida, TIPO_ACCION tipoAccion);


    //Destructor
    ~Tablero();


};


#endif //TP3_NOSFERATU_TABLERO_H
