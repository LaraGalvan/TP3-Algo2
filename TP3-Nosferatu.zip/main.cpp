#include "Juego.h"
#include <ctime>
#include <iostream>

int main() {
    srand ( time(nullptr) );
    Juego juego;


    return 0;
}
