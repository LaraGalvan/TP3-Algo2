#ifndef VAMPIRELLA_H_
#define VAMPIRELLA_H_

#include "Vampiro.h"
#include "Utiles.h"

class Vampirella : public Vampiro {

private:
    //atributos
    bool esMurcielago;
    bool inmuneEstacasAgua;

public:
    //constructor
	Vampirella(int id, int fila, int columna);

    //PRE:
    //POST:imprime por pantalla las opciones de defensa y le da al usuario la opcion a elegir
    void elegirDefensa();

    //PRE:
    //POST: se setea true que se puede defender de cualquier ataque
    void defender();

    //PRE:
    //POST:imprime por pantalla su nombre, sus atributo y su ubicacion
    void mostrar() override;

};


#endif /* VAMPIRELLA_H_ */
