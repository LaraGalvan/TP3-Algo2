#ifndef CASILLEROPRECIPICIO_H_
#define CASILLEROPRECIPICIO_H_

#include "Casillero.h"

class CasilleroPrecipicio : public Casillero {
public:
    //constructor
    CasilleroPrecipicio(int fila, int columna);

};


#endif /* CASILLEROPRECIPICIO_H_ */
