#include "Vampirella.h"
#include "Constantes.h"

Vampirella::Vampirella(int id, int fila, int columna) : Vampiro(id, fila, columna) {
    nombreMapa= LETRA_VAMPIRELLA;
    this->esMurcielago = false;
    this->inmuneEstacasAgua = false;
    this->recargaEnergiaTurno = 6;
    this->energiaMinimaAtaque = 4;
    this->energiaMinimaDefensa = 5;
}

void Vampirella::elegirDefensa() {
    defensaElegida = DEFENSA_NINGUN_ELEMENTO;
    cout << endl << "Vampirella se vuelve murciélago!" << endl;
    cout << "Si alguien la intenta atacar con estacas o agua bendita en el" << endl <<  "siguiente turno se quedará con las ganas.." << endl;

}

void Vampirella::defender() {
    seDefiendeDelAtaque = true;
}

void Vampirella::mostrar() {
    std::cout << "\n Soy Vampirella" << endl;
    mostrarAtributos();
}
