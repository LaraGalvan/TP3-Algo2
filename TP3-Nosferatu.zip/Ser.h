#ifndef SER_H_
#define SER_H_

#include "Objeto.h"
#include "Utiles.h"
#include "Inventario.h"

const float PORCENTAJE_ARMADURA = 1.0;

class Ser : public Objeto {

protected:
    //atributos
    float energia;

	float vida;

	float armadura;

	float fuerza;

	Inventario* inventario;

	float recargaEnergiaTurno;

	float energiaMinimaAtaque;

	float energiaMinimaDefensa;

	DEFENSA_ELEGIDA defensaElegida;

	bool seDefiendeDelAtaque;

public:

	//PRE: -
	//POST: Construye la entidad, llamando al inicializador de la clase madre
	Ser(int id, int fila, int columna);

	//PRE: -
	//POST: Muestra por pantalla los atributos
	void mostrarAtributos();

    //PRE:
    //POST:devuelve true si fue exitoso el elegir el arma para atacar
	virtual bool elegirArma(Accion &error, ITEM_ELEGIDO &armaElegida) = 0;

    //PRE:
    //POST:imprime por pantalla las opciones de las armas a utilizar
	virtual void mostrarOpcionesArmas(Accion &error, ITEM_ELEGIDO &armaElegida) = 0;

    //PRE: -
    //POST: Muestra por pantalla los objetos del inventario
    virtual void mostrarInventario() = 0;

    //PRE: Recibe al personaje a ser atacado
    //POST: Se realiza el ataque correspondiente
    virtual void atacar(ITEM_ELEGIDO arma) = 0;

    //PRE: Recibe al personaje atacante
    //POST: Se modifican los atributos del personaje atacado
    virtual void recibeAtaque(Ser* atacante, ITEM_ELEGIDO arma) = 0;

    //PRE: Recibe al personaje atacante, un arma elegida y la cantidad de vida perdida
    //POST: Se muestra por pantalla
    virtual void mostrarAtaqueRecibido(Ser* atacante, ITEM_ELEGIDO arma, int vidaQuitada) = 0;

    //PRE: -
    //POST: Devuelve el porcentaje del ataque teniendo en cuenta la armadura del personaje atacado
    float proteccionArmaduraAtaque();


    //PRE: -
    //POST: se ejecuta la defensa correspondida al ser
    virtual void defender() = 0;

	//PRE: -
	//POST: Devuelve true si el personaje tiene energia suficiente para realizar el ataque. False en caso contrario
	bool tieneEnergiaAtaque(Accion &error);


    //PRE:
    //POST:imprime por pantalla las opciones de defensa y le da al usuario la opcion a elegir
	virtual void elegirDefensa() = 0;

    //PRE:
    //POST: devuelve el numero de la defensa elegida
	DEFENSA_ELEGIDA obtenerDefensa();

	//PRE: -
	//POST: Devuelve true si el personaje tiene energia suficiente para defenderse. False en caso contrario
	bool tieneEnergiaDefensa(Accion &error);

	//PRE:
	//POST:devuelve true si se esta defendiendo de ataque
	bool seEstaDefendiendoDelAtaque();

	//PRE:
	//POST: devuelve true si se termino la defensa
	void seTerminoLaDefensa();

	//PRE: -
    //POST: Se le incrementa a la energia el valor de la recarga por turno
    void recargarEnergiaPorTurno();

    //PRE: -
    //POST: Si el valor pasado por parametro supera los limites correspondientes se setea el valor y lo devuelve
    void correcionLimiteEnergia();

    //PRE: -
    //POST: Si el atributo vida supera los limites correspondientes se setea y lo devuelve
    void correcionLimiteVida();


    //PRE: -
    //POST: Devuelve la vida del personaje
    float obtenerVida();

    //PRE: -
    //POST: Devuelve la energia que tiene el personaje
    float obtenerEnergia();

    //PRE: -
    //POST: Devuelve la armadura que tiene el personaje
    float obtenerArmadura();

    //PRE: -
    //POST: Devuelve la fuerza que tiene el personaje
    float obtenerFuerza();
    
    //PRE: -
    //POST: Setea el atributo nuevaVida del personaje
	void setVida(float nuevaVida);

	//PRE: Recibe la cantidad de vida a incrementar
	//POST: Se aumenta el atributo vida
	void aumentarVida(float cantidad);

	//PRE: Recibe la cantidad de vida a disminuir
	//POST: Se disminuye el atributo vida
	void disminuirVida(float cantidad);
	
    //PRE: -
    //POST: Setea la nuevaEnergia del personaje
    void setEnergia(float nuevaEnergia);

    //PRE: Recibe la cantidad de energia a aumentar
    //POST: Se aumenta el atributo energia
    void aumentarEnergia(int aumentoEnergia);

    //PRE: Recibe la cantidad de energia a disminuir
    //POST: Disminuye la energia pasada por parametro al ser
    void disminuirEnergia(int energiaConsumida);

    //PRE: -
    //POST: Setea la nuevaArmadura del personaje
    void setArmadura(float nuevaArmadura);

    //PRE:
    //POST: Aumenta la cantidad de armadura del ser
    void aumentarArmadura(float aumentoArmadura);

    void disminuirArmadura(float armaduraPerdida);

    //PRE: -
    //POST: Setea la nuevaFuerza del personaje
    void setFuerza(float nuevaFuerza);


    //PRE: -
    //POST: Setea los atributos del ser
    void setAtributos(float nuevaVida, float nuevaFuerza, float nuevaArmadura, float nuevaEnergia);

    //PRE: -
    //POST: Setea el inventario del ser
    void setInventario(Inventario* inventario);

    //PRE:
    //POST: Devuelve el inventario del ser
    Inventario* getInventario();

    //PRE:
    //POST: devuelve true si es humano
    bool esHumano();

    //PRE:
    //POST: devuelve true si es monstruo
    bool esMonstruo();

    //PRE:
    //POST: devuelve true si es cazador o Vanesa
    bool esCazadorGeneral();

    //PRE:
    //POST: devuelve true si es cazador
    bool esCazador();


    //PRE:
    //POST: devuelve true si es Vanesa
    bool esVanesa();

    //PRE:
    //POST: devuelve true si es zombi
    bool esZombi();

    //PRE:
    //POST: devuelve true si es humano simple
    bool esHumanoSimple();

    //PRE:
    //POST: devuelve true si es vampiro
    bool esVampiroGeneral();

    //PRE:
    //POST: devuelve true si es vampiro solamente
    bool esVampiro();

    //PRE:
    //POST: devuelve true si es vampirella
    bool esVampirella();

    //PRE:
    //POST: devuelve true si es Nosferatu
    bool esNosferatu();

    //PRE:
    //POST: devuelve true si es ser esta vivo
    bool estaVivo();

    //PRE: Recibe los datos de cada cantidad que puede haber en el inventario
    //POST: Guarda las cantidades en el inventario del Ser
    void guardarEnInventario(unsigned int cantAgua, unsigned int cantCruces, unsigned int cantEstacas,
                             unsigned int cantBalas, bool tieneEscopeta);

    //PRE:
    //POST:imprime por pantalla su nombre, sus atributo, su ubicacion y si tiene, su inventario
    void mostrar() override;

    //destructor
    virtual ~Ser();
};




#endif /* SER_H_ */
