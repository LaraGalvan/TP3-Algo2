#include <sstream>
#include "CasilleroMontania.h"
#include "Tablero.h"
#include "CasilleroVolcan.h"
#include "CasilleroPrecipicio.h"
#include "CasilleroVacio.h"
#include "CasilleroLago.h"
#include "CasilleroCamino.h"
#include "Arbol.h"
#include "Constantes.h"
#include "Gotoxy.h"

enum CUADRANTES {
    NO = 1, NE = 3, SO = 2, SE = 4
};

const string VOLCAN = "V";
const string MONTANIA = "M";
const string VACIO = "O";
const string LAGO = "L";
const string CAMINO = "C";
const string PRECIPICIO = "P";


Tablero::Tablero(LectorArchivo &archivo) {
    setTamano(archivo.leerLinea());
    crearMatrizVacia();
    crearCasilleros(archivo);
    this->diccionario = new Arbol;
}

void Tablero::setTamano(const string &linea) {
    string palabra;
    istringstream iss(linea);

    iss >> palabra;
    this->alto = stoi(palabra);

    iss >> palabra;
    this->ancho = stoi(palabra);

}

int Tablero::getAncho() {
    return ancho;
}

int Tablero::getAlto() {
    return alto;
}

void Tablero::crearMatrizVacia() {
    matriz = new Casillero **[alto];

    for (int i = 0; i < alto; i++) {
        matriz[i] = new Casillero *[ancho];
        for (int j = 0; j < ancho; j++) {
            matriz[i][j] = nullptr;
        }
    }
}

void Tablero::crearCasilleros(LectorArchivo &lectorTablero) {
    string palabra;
    int fila = 0;
    while (!lectorTablero.esFinalArchivo()) {
        int columna = 0;

        istringstream iss(lectorTablero.leerLinea());

        while (iss >> palabra) {
            crearCasillero(palabra, fila, columna);
            columna++;
        }
        fila++;
    }
}

void Tablero::crearCasillero(const string &palabra, int fila, int columna) {
    if (palabra == MONTANIA) {
        matriz[fila][columna] = new CasilleroMontania(fila, columna);
    } else if (palabra == VOLCAN) {
        matriz[fila][columna] = new CasilleroVolcan(fila, columna);
    } else if (palabra == VACIO) {
        matriz[fila][columna] = new CasilleroVacio(fila, columna);
    } else if (palabra == PRECIPICIO) {
        matriz[fila][columna] = new CasilleroPrecipicio(fila, columna);
    } else if (palabra == LAGO) {
        matriz[fila][columna] = new CasilleroLago(fila, columna);
    } else if (palabra == CAMINO) {
        matriz[fila][columna] = new CasilleroCamino(fila, columna);
    }
}

void Tablero::rellenar(LectorArchivo &lector) {
    string palabra, nombre, segundaPalabra;
    int cantidad, fila, columna, id;
    istringstream iss(lector.leerLinea());

    while (!lector.esFinalArchivo()) {
        istringstream iss(lector.leerLinea());
        lector.procesarObjeto(nombre, fila, columna, cantidad, id, iss);
        agregarObjeto(nombre, fila, columna, cantidad, id);
    }
}

void Tablero::agregarObjeto(const string &nombre, int fila, int columna, int cantidad, int id) {
    matriz[fila - 1][columna - 1]->crearObjeto(nombre, id, cantidad);
    if (nombre == NOMBRE_CRUZ || nombre == NOMBRE_BALA || nombre == NOMBRE_AGUA || nombre == NOMBRE_ESCOPETA ||
        nombre == NOMBRE_ESTACA ) {
        diccionario->insertar(id, matriz[fila - 1][columna - 1]->devolverItem());
    } else {
        diccionario->insertar(id, matriz[fila - 1][columna - 1]->devolverSer());
    }
}

void Tablero::agregarSer(const string &nombre, int fila, int columna, int cantidad, int id, float vida,
                         float armadura, float fuerza, float energia) {
    agregarObjeto(nombre, fila, columna, cantidad, id);
    dynamic_cast<Ser *>(matriz[fila - 1][columna - 1]->devolverSer())->setAtributos(vida, fuerza, armadura, energia);
}

Casillero *Tablero::devolverCasillero(int fila, int columna) {
    return matriz[fila - 1][columna - 1];
}

void Tablero::eliminarObjeto(int fila, int columna) {
    diccionario->borrar(matriz[fila - 1][columna - 1]->devolverSer()->obtenerID());
    matriz[fila - 1][columna - 1]->eliminarObjeto();
}

void Tablero::eliminarItem(int fila, int columna) {
    diccionario->borrar(matriz[fila - 1][columna - 1]->devolverItem()->obtenerID());
    matriz[fila - 1][columna - 1]->eliminarItem();
}

bool Tablero::haySer(int filaCasillero, int columnaCasillero) {
    return matriz[filaCasillero - 1][columnaCasillero - 1]->tieneSer();
}

void Tablero::mostrar() {
    int y = 6, x;
    ImpresionesPantalla::impresionCoordenadas(alto, ancho);
    ImpresionesPantalla::referenciasTablero();
    for (int i = 0; i < alto; i++) {
        x = 60;
        for (int j = 0; j < ancho; j++) {
            matriz[i][j]->mostrar(y, x);
            x+=6;
        }
        cout << endl;
        y+=2;
    }
}

bool Tablero::busquedaPorCuadrante(int cuadrante, int objeto) {
    int filaInicio, filaFin, columnaInicio, columnaFin;
    definirLimitesCuadrantes(cuadrante, filaInicio, filaFin, columnaInicio, columnaFin);
    return busquedaCuadranteElegido(filaInicio, filaFin, columnaInicio, columnaFin, objeto);
}

void
Tablero::definirLimitesCuadrantes(int cuadrante, int &filaInicio, int &filaFin, int &columnaInicio, int &columnaFin) {
    switch (cuadrante) {
        case (NO):
            filaInicio = COORDENADA_MINIMA, filaFin = alto / 2, columnaInicio = COORDENADA_MINIMA, columnaFin =
                    ancho / 2;
            break;
        case (NE):
            filaInicio = COORDENADA_MINIMA, filaFin = alto / 2, columnaInicio = (ancho / 2) + 1, columnaFin = ancho;
            break;
        case (SO):
            filaInicio = (alto / 2) + 1, filaFin = alto, columnaInicio = COORDENADA_MINIMA, columnaFin = ancho / 2;
            break;
        case (SE):
            filaInicio = (alto / 2) + 1, filaFin = alto, columnaInicio = (ancho / 2) + 1, columnaFin = ancho;
            break;
        default:
            break;
    }
}

char Tablero::devolverNombreFichaObjeto(int objeto) {
    char nombreObjeto = 0;
    switch (objeto) {
        case (HUMANO):
            nombreObjeto = LETRA_HUMANO;
            break;
        case (AGUA):
            nombreObjeto = LETRA_AGUA;
            break;
        case (BALA):
            nombreObjeto = LETRA_BALA;
            break;
        case (CV):
            nombreObjeto = LETRA_CV;
            break;
        case (CRUZ):
            nombreObjeto = LETRA_CRUZ;
            break;
        case (ESCOPETA):
            nombreObjeto = LETRA_ESCOPETA;
            break;
        case (ESTACA):
            nombreObjeto = LETRA_ESTACA;
            break;
        case (NOSFERATU):
            nombreObjeto = LETRA_NOSFERATU;
            break;
        case (VAMPIRO):
            nombreObjeto = LETRA_VAMPIRO;
            break;
        case (VAMPIRELLA):
            nombreObjeto = LETRA_VAMPIRELLA;
            break;
        case (VANESA):
            nombreObjeto = LETRA_VANESA;
            break;
        case (ZOMBI):
            nombreObjeto = LETRA_ZOMBI;
        default:
            break;
    }

    return nombreObjeto;
}

bool Tablero::busquedaCuadranteElegido(int &filaInicio, int &filaFin, int &columnaInicio, int &columnaFinal,
                                       int objeto) {
    bool encontrado;
    char fichaObjeto = devolverNombreFichaObjeto(objeto);

    if (fichaObjeto == LETRA_HUMANO) {
        encontrado = busquedaEspecialHumanos(filaInicio, filaFin, columnaInicio, columnaFinal);
    } else if (fichaObjeto == LETRA_VAMPIRO) {
        encontrado = busquedaEspecialVampiros(filaInicio, filaFin, columnaInicio, columnaFinal);
    } else {
        encontrado = busquedaGeneral(filaInicio, filaFin, columnaInicio, columnaFinal, fichaObjeto);
    }

    return encontrado;
}

bool Tablero::busquedaGeneral(int &filaInicio, int &filaFin, int &columnaInicio, int &columnaFinal,
                              char fichaObjeto) {
    bool encontrado = false;
    int fila = filaInicio;
    int columna;

    while (fila <= filaFin && !encontrado) {
        columna = columnaInicio;
        while (columna <= columnaFinal && !encontrado) {
            if (matriz[fila - 1][columna - 1]->tieneSer() &&
                    matriz[fila - 1][columna - 1]->devolverSer()->obtenerNombreMapa() == fichaObjeto) {
                encontrado = true;
            } else if (matriz[fila - 1][columna - 1]->tieneItem() &&
                       matriz[fila - 1][columna - 1]->devolverItem()->obtenerNombreMapa() == fichaObjeto) {
                encontrado = true;
            }
            columna++;
        }
        fila++;
    }

    return encontrado;
}

bool Tablero::busquedaEspecialHumanos(int &filaInicio, int &filaFinal, int &columnaInicio, int &columnaFinal) {
    bool encontrado = false;
    int fila = filaInicio;
    int columna;

    while (fila <= filaFinal && !encontrado) {
        columna = columnaInicio;
        while (columna <= columnaFinal && !encontrado) {
            if (matriz[fila - 1][columna - 1]->tieneSer()) {
                char fichaObjeto = matriz[fila - 1][columna - 1]->devolverSer()->obtenerNombreMapa();
                if (fichaObjeto == LETRA_HUMANO || fichaObjeto == LETRA_CV || fichaObjeto == LETRA_VANESA)
                    encontrado = true;
            }
            columna++;
        }
        fila++;
    }

    return encontrado;
}

bool Tablero::busquedaEspecialVampiros(int &filaInicio, int &filaFinal, int &columnaInicio, int &columnaFinal) {
    bool encontrado = false;
    int fila = filaInicio;
    int columna;

    while (fila <= filaFinal && !encontrado) {
        columna = columnaInicio;
        while (columna <= columnaFinal && !encontrado) {
            if (matriz[fila - 1][columna - 1]->tieneSer()) {
                char fichaObjeto = matriz[fila - 1][columna - 1]->devolverSer()->obtenerNombreMapa();
                if (fichaObjeto == LETRA_VAMPIRO || fichaObjeto == LETRA_NOSFERATU || fichaObjeto == LETRA_VAMPIRELLA) {
                    encontrado = true;
                }
            }
            columna++;
        }
        fila++;
    }

    return encontrado;
}

bool Tablero::hayItem(int fila, int columma) {
    return matriz[fila - 1][columma - 1]->tieneItem();
}

bool Tablero::hayObjetoEnCasillero(int fila, int columna) {
    return matriz[fila - 1][columna - 1]->tieneSer() || matriz[fila - 1][columna - 1]->tieneItem();
}

Arbol *Tablero::getDiccionario() {
    return this->diccionario;
}

Objeto *Tablero::devolverObjetoEnCasillero(int fila, int columna) {
    if (matriz[fila - 1][columna - 1]->tieneSer())
        return matriz[fila - 1][columna - 1]->devolverSer();
    else if (matriz[fila-1][columna-1]->tieneItem())
        return matriz[fila-1][columna-1]->devolverItem();
    return nullptr;
}

void Tablero::ingresarCoordenadas(int &fila, int &columna) {
    cout << endl << "Ingrese la fila: ";
    string filaIngresada;
    cin >> filaIngresada;
    fila = Utiles::ingresoValido(filaIngresada, 1, alto);
    cout << "Ingrese la columna: ";
    string columnaIngresada;
    cin >> columnaIngresada;
    columna = Utiles::ingresoValido(columnaIngresada, 1, ancho);
}

bool Tablero::hayQuienAtacarDefender(Ser *personaje, Accion &error, int filaElegida, int columnaElegida, TIPO_ACCION tipoAccion) {
    bool exito = false;
    if (tipoAccion == ATAQUE) {
        if (haySer(filaElegida, columnaElegida)) {
            Ser *atacado = dynamic_cast<Ser *>(devolverCasillero(filaElegida,columnaElegida)->devolverSer());
            if (personaje->esMonstruo() && atacado->esHumano() || personaje->esHumano() && atacado->esMonstruo()) {
                exito = true;
            } else {
                error = ES_DE_MISMO_BANDO;
            }
        } else {
            error = NO_HAY_A_QUIEN_ATACAR;
        }
    } else { //DEFENSA
        if (haySer(filaElegida, columnaElegida)) {
            Ser *defendido = dynamic_cast<Ser *>(devolverCasillero(filaElegida,columnaElegida)->devolverSer());
            if ( (personaje->esNosferatu() && defendido->esVampiro()) || (personaje->esVanesa() && personaje->esHumano()) ) {
                exito = true;
            } else if (personaje->esNosferatu() && !defendido->esVampiro()){
                error = NO_HAY_CON_QUIEN_INTERCAMBIAR;
            } else { //Vanesa pero no hay humano que defender
                error = NO_HAY_QUIEN_SANAR;
            }
        }
        else {
            error = NO_HAY_NADIE_DEFENSA;
        }
    }
    return exito;
}


Tablero::~Tablero() {
    for (int i = 0; i < alto; i++) {
        for (int j = 0; j < ancho; j++) {
            if (matriz[i][j] != nullptr) {
                delete matriz[i][j];
            }
        }
        delete[]matriz[i];
    }
    delete [] matriz;
    delete diccionario;
}
