#ifndef TP3_RANGOS_H
#define TP3_RANGOS_H

#include <iostream>
#include "Objeto.h"
#include "Arbol.h"
#include "Casillero.h"
#include "Utiles.h"
#include "Jugador.h"
#include "Tablero.h"
#include "Humano.h"
#include "Vampiro.h"
#include "Bala.h"
#include "Agua.h"
#include "Monstruo.h"
#include "Grafo.h"
#include "EscrituraArchivo.h"
#include "ImpresionesPantalla.h"
#include "Constantes.h"
#include <iomanip>


class Rangos {
private:
    //atributos
    Tablero* tablero;

public:
    //constructor
    Rangos(Tablero* tablero);

    //PRE:
    //POST: devuelve true si la ubicacion esta en rango
    bool estaEnRango(int filaAtacante, int columnaAtacante ,int &filaElegida, int &columnaElegida, TIPO_ACCION tipoAccion, Accion &error, ITEM_ELEGIDO itemElegido, Ser* personaje);

    //destructor
    ~Rangos();

private:
    //PRE:
    //POST: devuelve true si la ubicacion esta en rango de radio 1
    bool estaEnRangoRadio1(int filaAtacante, int columnaAtacante , int &filaElegida, int &columnaElegida, Accion &error);

    //PRE:
    //POST: devuelve true si la ubicacion esta en rango de radio 2
    bool estaEnRangoRadio2(int filaAtacante, int columnaAtacante , int &filaElegida, int &columnaElegida, Accion &error);

    //PRE:
    //POST: define el rango del radio
    bool definirRangosConRadio(int radio, int filaAtacante, int columnaAtacante , int &filaElegida, int &columnaElegida, Accion &error);

    //PRE:
    //POST:corrige el rango para no salir de la matriz
    void corregirRangos(int arribaDerecha[2], int arribaIzquierda[2], int abajoDerecha[2], int abajoIzquierda[2]);

    //PRE:
    //POST:devuelve true si la ubicacion esta en rango de radio flor
    bool estaEnRangoRadioFlor(int filaAtacante, int columnaAtacante , int &filaElegida, int &columnaElegida, Accion &error, Ser* personaje);

    //PRE:
    //POST:corrige el rango de radio flor
    void corregirRangoFlor(int arriba[2] , int abajo[2] , int izquierda[2] , int derecha[2] );

    //PRE:
    //POST:setea las coordenadas aleatoriamente del ataque del zombi
    void coordenadasAtaqueAleatorioZombi(int filaAtacante , int columnaAtacante , int &filaElegida, int &columnaElegida,int arriba[2] , int abajo[2] , int izquierda[2] , int derecha[2] , Ser* personaje);

    //PRE:
    //POST:devuelve true si hay un humano alrededor de zombi
    bool hayHumanoAlrededorZombi(int arriba[2] , int abajo[2] , int izquierda[2] , int derecha[2] );

    //PRE:
    //POST:muestra el rango radial
    void mostrarRangoRadial(int abajoIzquierda[2] , int abajoDerecha[2] , int arribaIzquierda[2] , int arribaDerecha[2] );

    //PRE:
    //POST: muestra el rango flor
    void mostrarRangoFlor(int arriba[2] , int abajo[2] , int izquierda[2] , int derecha[2] );
};


#endif //TP3_RANGOS_H
