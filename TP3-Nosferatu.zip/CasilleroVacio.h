#ifndef CASILLEROVACIO_H_
#define CASILLEROVACIO_H_

#include "Casillero.h"

class CasilleroVacio : public Casillero {
public:
    //constructor
    CasilleroVacio(int fila, int columna);
};


#endif /* CASILLEROVACIO_H_ */
