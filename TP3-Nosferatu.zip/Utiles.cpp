#include "Utiles.h"
#include "Constantes.h"
#include <unistd.h>

int Utiles::buscarNumeroAleatorio(int minimo, int maximo) {
    maximo++;
    return ((rand() % (maximo-minimo)+minimo));
}

void Utiles::botonContinuar(){
    string continuar;
    cout << "\nPRESIONE ENTER PARA CONTINUAR.."<< endl;
    cin.get();
    cin.get();
}

void Utiles::limpiarPantalla(){
    system(LIMPIAR);
}

int Utiles::ingresoValido(string input, int minimo, int maximo) {
    while (!(esNumeroValido(input, minimo, maximo)) )  {
        if (!esStringNumerico(input)) {
            cout << "El valor ingresado no es un número. Intente de nuevo.. " << endl;
        } else {
            cout << "El numero ingresado no es una opción. Intente de nuevo.. " << endl;
        }
        cin >> input;
    }
    cout << "Opcion ingresada: " << input << endl;
    return (stoi(input));
}

bool Utiles::esStringNumerico(string input) {
    int i = 0;
    bool esNum = true;
    while (esNum && i < int(input.length()) ) {
        if ( !(isdigit(input[i])) ) {
            esNum = false;
        }
        i++;
    }
    return esNum;
}

bool Utiles::esNumeroValido(const string& ingreso, int opcionMinima, int opcionMaxima) {
    if (!esStringNumerico(ingreso)) {
        return false;
    }
    int opcionNumerica = stoi(ingreso);
    return (opcionNumerica >= opcionMinima && opcionNumerica <= opcionMaxima);
}

bool Utiles::archivoExistente(const string& nombreArchivo) {
    return (access( nombreArchivo.c_str(), F_OK ) != -1);
}

string Utiles::obtenerNombreObjeto(char fichaObjeto) {
    string nombre;
    switch (fichaObjeto) {
        case LETRA_HUMANO:
            nombre = NOMBRE_HUMANO; break;
        case LETRA_CV:
            nombre = NOMBRE_CAZADOR; break;
        case LETRA_VANESA:
            nombre = NOMBRE_VANESA; break;
        case LETRA_VAMPIRO:
            nombre = NOMBRE_VAMPIRO; break;
        case LETRA_VAMPIRELLA:
            nombre = NOMBRE_VAMPIRELLA; break;
        case LETRA_NOSFERATU:
            nombre = NOMBRE_NOSFERATU; break;
        case LETRA_ZOMBI:
            nombre = NOMBRE_ZOMBI; break;
        case LETRA_CRUZ:
            nombre = NOMBRE_CRUZ; break;
        case LETRA_AGUA:
            nombre = NOMBRE_AGUA; break;
        case LETRA_BALA:
            nombre = NOMBRE_BALA; break;
        case LETRA_ESCOPETA:
            nombre = NOMBRE_ESCOPETA; break;
        case LETRA_ESTACA:
            nombre = NOMBRE_ESTACA; break;
        default: break;
    }
    return nombre;
}

void Utiles::dormir(int segundos) {
    sleep(segundos);
}

void Utiles::eliminarArchivo(const string& pathArchivo) {
    if (archivoExistente(pathArchivo)) {
        if (remove(pathArchivo.c_str()) != 0) {
            cout << "Hubo un error al intentar eliminar el archivo " << pathArchivo << endl;
        }
    }
}

void Utiles::mostrarError(Accion tipoError) {
    if (tipoError != ES_REALIZABLE) {
        cout << endl;
        if (tipoError == POSICION_FUERA_RANGO) {
            cout << "La posición ingresada esta fuera de rango. Intente de nuevo" << endl;
        } else if (tipoError == MISMO_CASILLERO_QUE_ATACANTE) {
            cout << "El casillero elegido es el del personaje seleccionado. Intente de nuevo" << endl;
        } else if (tipoError == SIN_BALAS_SUFICIENTES) {
            cout << "El personaje no tiene balas suficientes. Intente de nuevo" << endl;
        } else if (tipoError == SIN_ENERGIA_ATAQUE) {
            cout << "El personaje no tiene energia suficiente para el ataque. Intente de nuevo" << endl;
        } else if (tipoError == SIN_ENERGIA_DEFENSA) {
            cout << "El personaje no tiene energia suficiente para la defensa. Intente de nuevo" << endl;
        } else if (tipoError == NO_HAY_AGUA_EN_INVENTARIO) {
            cout << "El agua bendita no se encuentra en el inventario. Intente de nuevo" << endl;
        } else if (tipoError == NO_HAY_ESCOPETA_EN_INVENTARIO) {
            cout << "La escopeta no se encuentra en el inventario. Intente de nuevo" << endl;
        } else if (tipoError == INVENTARIO_VACIO) {
            cout << "El inventario se encuentra vacío! Intente de nuevo" << endl;
        } else if (tipoError == NO_HAY_A_QUIEN_ATACAR) {
            cout << "En el casillero elegido no hay a quien atacar. Intente de nuevo" << endl;
        } else if (tipoError == ES_DE_MISMO_BANDO) {
            cout << "En el casillero elegido hay un ser del mismo bando! Intente de nuevo" << endl;
        } else if (tipoError == NO_HAY_NADIE_DEFENSA) {
            cout << "En el casillero no hay nadie! Intente de nuevo" << endl;
        } else if (tipoError == NO_HAY_QUIEN_SANAR) {
            cout << "Vanesa no encuentra a quíen sanar con su Agua Bendita en el casillero elegido!\nIntente de nuevo" << endl;
        } else if (tipoError == NO_HAY_CON_QUIEN_INTERCAMBIAR){
            cout << "Nosferatu no encuentra con quién intercambiar sus puntos de vida en el casillero elegido!\nIntente de nuevo" << endl;
        } else if (tipoError == ZOMBI_NO_TIENE_QUIEN_ATACAR_ALEATORIAMENTE){
            cout << "El zombi no tiene a ningún humano alrededor para realizar su mordedura al azar" << endl;
        } else if (tipoError == CAZADOR_ESTA_SOLO_EN_EQUIPO) {
            cout << "El cazador gastó su turno queriendo ayudar al equipo... pero como esta solo..." << endl;
        } else if (tipoError == VANESA_NO_EVITA_CONVERSION_DE_UN_SANO){
            cout << "Vanesa va a ayudar siempre a su equipo, pero ahora su ayuda no es necesaria: Esta sano" << endl;
        } else if (tipoError == NOSFERATU_QUIERE_INTERCAMBIAR_CON_MENOR_VIDA){
            cout << "Nosferatu sera vil, pero no tonto. Vio que el vampiro tiene menos vida!" << endl;
        } else if (tipoError == NO_PUEDE_MOVERSE_COSTO_INFINITO){
            cout << "No puedes moverte a esta casilla!" << endl;
        } else if (tipoError == MISMA_CASILLA_QUE_ESTOY_PARA_MOVERSE){
            cout << "El personaje YA ESTA en esa casilla!" << endl;
        } else if (tipoError == SIN_ENERGIA_MOVERSE) {
            cout << "Como verás, no se puede llegar con tu energia actual" << endl;
        }
    }
}