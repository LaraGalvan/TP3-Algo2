#include "Zombi.h"
#include "Constantes.h"

const int NULO = 0;

const float PORCENTAJE_CAZADOR_SACAR_VIDA_ESTACA = 0.2;
const float PORCENTAJE_VANESA_SACAR_VIDA_ESTACA = 0.25;

Zombi::Zombi(int id, int fila, int columna) : Monstruo(id, fila, columna) {
    nombreMapa = LETRA_ZOMBI;
    this->recargaEnergiaTurno = 5;
    this->energiaMinimaAtaque = 5;
    this->energiaMinimaDefensa = 2;
}

void Zombi::atacar(ITEM_ELEGIDO arma) {
    disminuirEnergia(energiaMinimaAtaque);
}

void Zombi::recibeAtaque(Ser* atacante, ITEM_ELEGIDO arma) {
    int vidaQuitada;
    Humano* atacanteHumano = dynamic_cast<Humano *>(atacante);

    if (!seDefiendeDelAtaque) {
        if (atacante->esHumanoSimple()) {
            vidaQuitada = atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque();
        } else if (atacante->esCazador()) {
            if (arma == ITEM_ESCOPETA) {
                vidaQuitada = atacanteHumano->getPorcentajeAtaqueZombi() * atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque();
            } else if (arma == ITEM_ESTACA) {
                vidaQuitada = PORCENTAJE_CAZADOR_SACAR_VIDA_ESTACA * atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque() * proteccionArmaduraAtaque();
            }
        } else if (atacante->esVanesa()) {
            if (arma == ITEM_ESCOPETA) {
                vidaQuitada = atacanteHumano->getPorcentajeAtaqueZombi() * atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque();
            } else if (arma == ITEM_ESTACA) {
                vidaQuitada = PORCENTAJE_VANESA_SACAR_VIDA_ESTACA * atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque() * proteccionArmaduraAtaque();
            }
        }
        disminuirVida((int) vidaQuitada);
    }
    mostrarAtaqueRecibido(atacante,arma,vidaQuitada);
}

void Zombi::mostrarAtaqueRecibido(Ser *atacante, ITEM_ELEGIDO arma, int vidaQuitada) {
    string nombreArma;
    if (arma == ITEM_ESCOPETA) {
        nombreArma = "la escopeta";
    } else if (arma == ITEM_AGUA_BENDITA) {
        nombreArma = "el agua bendita";
    } else if (arma == ITEM_ESTACA) {
        nombreArma = "la estaca";
    }
    if (seDefiendeDelAtaque) {
        cout << "El zombi está bajo tierra! Has intentado atacarlo, pero solo perdiste tu tiempo.. " << endl;
    } else if (arma == ITEM_ESTACA){
        cout << "Al zombi la estaca no le hace nada! "<< endl;
    } else if (vidaQuitada) {
        cout << "Le has sacado hasta " << vidaQuitada << " puntos de vida al zombi con " << nombreArma << endl;
    }
}

void Zombi::mostrar() {
    std::cout << "\n Soy Zombi" << endl;
    mostrarAtributos();
    mostrarInventario();
}

void Zombi::mostrarInventario(){
    std::cout << std::endl << "\t INVENTARIO" << std::endl;
    if (inventario->inventarioVacio()) {
        std::cout << "...esta vacío --_(+,+)_--" << std::endl;
    } else if (inventario->getAguaBendita() > NULO) {
        std::cout << ". Agua Bendita: " << inventario->getAguaBendita() << std::endl;

    }
}

void Zombi::elegirDefensa() {
    defensaElegida = DEFENSA_ZOMBI_BAJO_TIERRA;
    aumentarVida(20);
    cout << "El zombi ahora está bajo Tierra por un turno! Si alguien intenta atacarlo " << endl;
    cout << "se quedará con las ganas. Además se agregan 20 puntos de vida" << endl;
}

void Zombi::defender() {
    seDefiendeDelAtaque = true;
}