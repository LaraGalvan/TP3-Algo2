#include "Vanesa.h"
#include "Constantes.h"

const int NULO = 0;

Vanesa::Vanesa(int id, int fila, int columna): Cazador(id, fila, columna) {
    nombreMapa = LETRA_VANESA;
    this->inmuneAtaqueVampirico = false;
    this->humanosProtegidos = false;
    this->recargaEnergiaTurno = 10;
    this->energiaMinimaAtaque = 8;
    this->energiaMinimaDefensa = 10;
    this->PORCENTAJE_ATAQUE_ZOMBI = 1.25;
    this->PORCENTAJE_ATAQUE_VAMPIRO = 0.4;
}

void Vanesa::elegirDefensa() {
    string input;
    bool ingresoDefensaValida = false;
    while (!ingresoDefensaValida) {
        cout << endl << "ELIJA UNA DEFENSA:" << endl;
        if (inventario->tieneAguaBendita()) {
            cout << "1 - Agua Bendita: " << endl;
        }
        if (inventario->tieneCruz()) {
            cout << "2 - Cruz: " << endl;
        }
        cout << "3 - Nada: " << endl;

        cin >> input;
        int opcionElegida = Utiles::ingresoValido(input, 1, 4);

        if (opcionElegida == 1 && inventario->tieneAguaBendita()) {
            defensaElegida = DEFENSA_CURAR_VANESA;
            ingresoDefensaValida = true;
        } else if (opcionElegida == 2 && inventario->tieneCruz()) {
            defensaElegida = DEFENSA_CRUZ;
            ingresoDefensaValida = true;
        } else if (opcionElegida == 3) {
            defensaElegida = DEFENSA_NINGUN_ELEMENTO;
            ingresoDefensaValida = true;
        } else {
            cout << "El numero ingresado no es una opción. Intente de nuevo.. " << endl;
        }
    }
}

void Vanesa::defender() {
    if (defensaElegida == DEFENSA_NINGUN_ELEMENTO) {
        aumentarVida(10);
        cout << endl << "Se aumento 10 de vida a Vanesa" << endl;
    } else if (defensaElegida == DEFENSA_CRUZ) {
        seDefiendeDelAtaque = true;
        cout << endl << "Si Vanesa es atacada por un vampiro, ella podrá salvarse de su ataque con la cruz de Jesucristo" << endl;
    }
}

void Vanesa::mostrar() {
    std::cout << "\n Soy Vanesa" << std::endl;
    mostrarAtributos();
    mostrarInventario();
}
