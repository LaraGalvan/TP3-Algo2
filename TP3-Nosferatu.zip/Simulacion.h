#ifndef TP3_NOSFERATU_SIMULACION_H
#define TP3_NOSFERATU_SIMULACION_H

#include <iostream>
#include "Objeto.h"
#include "Arbol.h"
#include "Casillero.h"
#include "Utiles.h"
#include "Jugador.h"
#include "Tablero.h"
#include "Humano.h"
#include "Vampiro.h"
#include "Bala.h"
#include "Agua.h"
#include "Monstruo.h"
#include "Grafo.h"
#include "EscrituraArchivo.h"
#include "ImpresionesPantalla.h"
#include "Constantes.h"
#include <iomanip>

#include "Movimientos.h"
#include "Rangos.h"

using namespace std;

class Simulacion {
private:
    //atributos
    Jugador *jugadores[2];

    Tablero *tablero;

    Arbol *personajes;

    Movimientos *movimientos;

    Rangos* rangos;

public:
    //Constructor, recibe un puntero al tablero
    Simulacion(Tablero *tablero, string tipoEjecucion,bool &finalDeJuego, bool &seGuardaPartida);

    //PRE: recibe por parametro un puntero al tablero
    //POST: setea el tablero
    void setTablero(Tablero *tablero);

    //PRE:
    //POST: Dependiendo de una opcion se ejecuta un metodo correspondiente
    void iniciar(bool &finalDeJuego, bool &seGuardaPartida);

    //PRE: -
    //POST: Devuelve una opcion numerica ingresada
    int ingresarMenuSimulacion();

    //PRE: -
    //POST: Devuelve un puntero al jugador
    Jugador *getJugador(int indiceJugador);

    //PRE: -
    //POST: Se cambian los turnos
    void interactuarPersonaje(Ser *personaje);

    //PRE: Recibe un personaje del tipo Ser
    //POST: Se muestran las opciones del personaje al jugador y retorna esa opcion ingresada
    int mostrarMenuPersonaje(Ser *personaje);

    //PRE: -
    //POST: Devuelve el id ingresado
    int ingresarID();

    //PRE: -
    //POST: Se realiza la busqueda del objeto u personaje a traves de su ID
    void buscarPersonajePorID();

    //PRE: -
    //POST: Se elige el bando seleccionado por el usuario
    void seleccionarNombreYBando();

    //PRE: -
    //POST: Se genera el turno del jugador a arrancar aleatoriamente
    void setQuienArranca();

    //PRE: Recibe el numero del primer jugador
    //POST: Se cambian los ordenes de los jugadores
    void cambiarOrdenJugadores(int primerJugador);

    //PRE: -
    //POST: Permite al usuario elegir el bando
    void elegirBando();

    //PRE: Recibe una opcion numerica
    //POST: Se cambian los bandos de los jugadores
    void procesarBando(int opcionBando);

    //PRE: -
    //POST: Se muestra por pantalla la cantidad de personajes de cada bando
    void mostrarCantidadBando();

    //PRE: Recibe una opcion de tipo entera
    //POST: Se ejecuta el metodo correspondiente a la opcion recibida por parametro
    void realizarAccionMenuSimulacion(int opcion, bool &seGuardaPartida,bool &finalDeJuego);

    //PRE: -
    //POST: Se muestra por pantalla los bandos correspondientes a los jugadores
    void mostrarBandos();

    //PRE: -
    //POST: Se muestra por pantalla el jugador que arranca el juego
    void mostrarQuienArranca();

    //PRE:
    //POS:muestra por pantalla quien le toca jugar
    void mostrarDeQuienEsTurno(int indiceJugadorActual);

    //PRE:
    //POST:arranca la simulacion, preguntando si quiere guardar y si no quiere, arranca con los personajes
    //del bando del jugador que empieza
    void comenzarSimulacion(bool seMuestraMensajeGuardar, bool &seGuardaPartida,bool &finalDeJuego);

    //PRE:
    //POST:elimina al personaje que murio del vector de ids
    void eliminarPersonaje(Ser *personaje, int indiceJugador);

    //PRE: -
    //POST: Se setean los vectores id de cada jugador
    void cargarIDsNuevaPartida();

    //PRE: -
    //POST: Se setea la cantidad de personajes de cada jugador
    void setCantidadPorJugador();

    //PRE: -
    //POST: Se recorre el tablero y se llama al metodo para setear el personaje del bando
    void recorrerTableroNuevaPartida();

    //PRE: Recibe un id de tipo entero y un bando de tipo string
    //POST: Se setea el personaje de un bando
    void setPersonajeBando(int id, const string &bando);

    //PRE: Recibe el numero de un jugador
    //POST: Se guarda la partida actual
    void guardarPartida(int indiceJugadorActual);

    //PRE:
    //POST:se guardan los datos de ambos jugadores
    void guardarDatosJugador(EscrituraArchivo &archivoPartida, int numeroJugador);

    //PRE:
    //POST:se guardan los items sueltos en el mapa
    void guardarDatosItems(EscrituraArchivo &archivoPartida);

    //PRE: Recibe un numero de jugador ( 1 o 2)
    //POST: Se le pregunta al jugador si desea guardar la partida
    void permitirGuardarPartida(int indiceJugadorActual, bool &seMuestraMensajeGuardar, bool &finalSimulacion, bool &seGuardaPartida);

    //PRE:
    //POST:setea el diccionario
    void setDiccionario(Arbol *diccionario);

    //PRE:
    //POST: setea el nombre del jugador
    void setNombreJugador(int numeroJugador, int indiceJugador);

    //PRE:
    //POST: setea el bando del jugador
    void setBando(const string &nuevoBando, int numeroJugador);

    //PRE:
    //POST: carga la cantidad de personajes
    void cargarCantidadPersonajes(int numeroJugador, int cantidadPersonajes);

    //PRE:
    //POST: se realiza el ataque y se ejecutan los cambios en los atributos
    void atacar(Ser* atacante, bool &ejecucionExitosa); //FUncion general de atacar

    //PRE:
    //POST:se realiza la defensa del personaje
    void defender(Ser* defensor, bool &ejecucionExitosa);

    //PRE:
    //POST:se realiza la defensa especial de algunos personajes determinados
    void defensaEspecial(Ser* defensor, Accion &error);

    //PRE:
    //POST:se realiza la defensa especial de Nosferatu y Vanesa
    void defensaNosferatuVanesa(int filaElegida, int columnaElegida, Ser* defensor, Accion &error);

    //PRE:
    //POST:se realiza la defensa especial de Nosferatu
    void defensaNosferatu(Ser *nosferatu, Accion &error, Vampiro *victimaNosferatu);

    //PRE:
    //POST:se realiza la defensa especial de Vanesa
    void defensaVanesa(Accion &error, Humano *salvado);

    //PRE:
    //POST:se cura al equipo del personaje
    void cazadorCuraEquipo(Ser* defensor, Accion &error, int indiceBandoHumanos);

    //PRE:
    //POST: devuelve el indice del bando
    int obtenerIndiceBando(string bandoRequerido);

    //PRE:
    //POST:devuelve true si hay solo un humano
    bool cazadorEstaSolo(int indiceBandoHumanos);

    //PRE:
    //POST: revisa la cantidad de turnos y controla hasta ejecutar determinada accion
    void accionesSegundoPlano(int indiceDeQuienJugoRecien);

    //PRE:
    //POST: si el atacado se esta defendiendo, se cancela su defnesa para atacarlo en el siguiente turno
    void cancelarDefensasDeAtaques(int indiceJugadorContrario);

    //PRE:
    //POST:elimina a los ids de los personajes muertos del bando
    void eliminarMuertosEquipoContrario(int indiceDeQuienJugoRecien);

    //PRE:
    //POST:revisa si se necesita hacer la conversion de humano a zombi o vampiro
    void revisarConversionesZombiVampiro(int indiceJugadorHumanos);

    //PRE:
    //POST:convierte el humano a vampiro
    void conversionVampiro(Humano* humano, int indiceJugadorHumanos);

    //PRE:
    //POST:convierte el humano a zombi
    void conversionZombi(Humano* humano, int indiceJugadorHumanos);

    //Destructor
    ~Simulacion();


};


#endif //TP3_NOSFERATU_SIMULACION_H
