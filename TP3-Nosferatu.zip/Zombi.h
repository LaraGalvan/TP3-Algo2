#ifndef ZOMBI_H_
#define ZOMBI_H_


#include "Monstruo.h"
#include "Utiles.h"
#include "Tablero.h"

class Zombi : public Monstruo {
public:
    //Constructor
	Zombi(int id, int fila, int columna);

    //PRE: Recibe al personaje a ser atacado
    //POST: Se realiza el ataque correspondiente
    void atacar(ITEM_ELEGIDO arma);

    //PRE: Recibe al personaje atacante
    //POST: Se modifican los atributos del personaje atacado
    void recibeAtaque(Ser* atacante, ITEM_ELEGIDO arma);

    //PRE: Recibe al personaje atacante, un arma elegida y la cantidad de vida perdida
    //POST: Se muestra por pantalla
    void mostrarAtaqueRecibido(Ser* atacante, ITEM_ELEGIDO arma, int vidaQuitada);

	//PRE:
	//POST:imprime por pantalla el inventario del zombi
    void mostrarInventario();


    //PRE:
    //POST:el zombi se esconde y aumenta su vida
    void elegirDefensa();

    //PRE:
    //POST: se setea true que se defiende del ataque
    void defender();

    //PRE:
    //POST:imprime por pantalla su nombre, sus atributo, su ubicacion y si tiene, su inventario
    void mostrar() override;

};


#endif /* ZOMBI_H_ */
