#ifndef TP3_NOSFERATU_CASILLEROMONTANIA_H
#define TP3_NOSFERATU_CASILLEROMONTANIA_H

#include "Casillero.h"

class CasilleroMontania : public Casillero {
public:
    //constructor
    CasilleroMontania(int fila, int columna);
};


#endif //TP3_NOSFERATU_CASILLEROMONTANIA_H
