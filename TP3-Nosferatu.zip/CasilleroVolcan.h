#ifndef CASILLEROVOLCAN_H_
#define CASILLEROVOLCAN_H_

#include "Casillero.h"

class CasilleroVolcan : public Casillero {
public:
	//Constructor
	CasilleroVolcan(int fila , int columna);

};


#endif /* CASILLEROVOLCAN_H_ */
