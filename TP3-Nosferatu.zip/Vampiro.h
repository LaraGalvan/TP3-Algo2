#ifndef VAMPIRO_H_
#define VAMPIRO_H_

#include "Monstruo.h"
#include "Elemento.h"
#include "Tablero.h"

class Vampiro : public Monstruo {

public:
    //constructor
	Vampiro(int id, int fila, int columna);

	//PRE: Recibe el personaje a atacar de tipo Ser
	//POST: Realiza el ataque decrementando la vida del personaje atacado
	//void atacar(Ser* personaje);
    void mostrarInventario(){};

    //PRE: Recibe al personaje a ser atacado
    //POST: Se realiza el ataque correspondiente
    void atacar(ITEM_ELEGIDO arma);

    //PRE: Recibe al personaje atacante
    //POST: Se modifican los atributos del personaje atacado
    void recibeAtaque(Ser* atacante, ITEM_ELEGIDO arma);

    //PRE: Recibe al personaje atacante, un arma elegida y la cantidad de vida perdida
    //POST: Se muestra por pantalla
    virtual void mostrarAtaqueRecibido(Ser* atacante, ITEM_ELEGIDO arma, int vidaQuitada);

    //PRE:
    //POST:imprime por pantalla las opciones de defensa y le da al usuario la opcion a elegir
    virtual void elegirDefensa();

    //PRE: -
    //POST: se ejecuta la defensa correspondida al ser
    virtual void defender();

    //PRE:
    //POST:imprime por pantalla su nombre, sus atributo y su ubicacion
    void mostrar() override;

};


#endif /* VAMPIRO_H_ */
