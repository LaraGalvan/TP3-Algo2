#include "Simulacion.h"
#include "Constantes.h"

Simulacion::Simulacion(Tablero *tablero, string tipoEjecucion, bool &finalDeJuego, bool &seGuardaPartida) {
    this->tablero = tablero;
    personajes = this->tablero->getDiccionario();
    jugadores[0] = new Jugador(tablero,personajes);
    jugadores[1] = new Jugador(tablero,personajes);
    movimientos = new Movimientos(tablero);
    rangos = new Rangos(tablero);

    if (tipoEjecucion == NUEVA_PARTIDA) {
        iniciar(finalDeJuego,seGuardaPartida);
    }
}

void Simulacion::iniciar(bool &finalDeJuego, bool &seGuardaPartida) {
    int opcion = 0;
    while (opcion != SALIR && !seGuardaPartida && !finalDeJuego) {
        Utiles::limpiarPantalla();
        opcion = ingresarMenuSimulacion();
        cout << endl;
        cout << endl;
        realizarAccionMenuSimulacion(opcion,seGuardaPartida,finalDeJuego);
    }
    Utiles::limpiarPantalla();
}

void Simulacion::realizarAccionMenuSimulacion(int opcionElegida, bool &seGuardaPartida, bool &finalDeJuego) {
    switch (opcionElegida) {
        case (BUSCAR_POR_ID):
            Utiles::limpiarPantalla();
            buscarPersonajePorID();
            Utiles::botonContinuar();
            break;
        case (MOSTRAR_TABLERO):
            Utiles::limpiarPantalla();
            tablero->mostrar();
            ImpresionesPantalla::impresionTituloTablero();
            Utiles::botonContinuar();
            break;
        case (MOSTRAR_CANTIDAD_POR_BANDO):
            Utiles::limpiarPantalla();
            mostrarCantidadBando();
            Utiles::botonContinuar();
            break;
        case (SELECCIONAR_BANDO): {
            Utiles::limpiarPantalla();
            seleccionarNombreYBando();
            setQuienArranca();
            mostrarBandos();
            cargarIDsNuevaPartida();

            Utiles::botonContinuar();
            mostrarQuienArranca();
            Utiles::dormir(2);
            comenzarSimulacion(false,seGuardaPartida,finalDeJuego);
            break;
        }
        default:
            break;
    }
}

void Simulacion::mostrarCantidadBando() {
    int humanos = Humano::devolverCantidadHumanos();
    int monstruos = Monstruo::devolverCantidadMonstruos();
    ImpresionesPantalla::impresionMostrarCantidadBando(humanos, monstruos);
}

void Simulacion::seleccionarNombreYBando() {
    jugadores[0]->setNumeroJugador(1);
    jugadores[1]->setNumeroJugador(2);
    elegirBando();
}

void Simulacion::setQuienArranca() {
    int numJugadorQueArranca = Utiles::buscarNumeroAleatorio(1, 2);
    cambiarOrdenJugadores(numJugadorQueArranca);
}

void Simulacion::cambiarOrdenJugadores(int primerJugador) {
    if (primerJugador == 2) {
        Jugador *aux = jugadores[0];
        jugadores[0] = jugadores[1];
        jugadores[1] = aux;
    }
}

void Simulacion::mostrarBandos() {
    cout << " JUGADOR " << jugadores[0]->getNumeroJugador() << "--> " << jugadores[0]->getBando() << endl;
    cout << " JUGADOR " << jugadores[1]->getNumeroJugador() << " --> " << jugadores[1]->getBando() << endl;
}

void Simulacion::mostrarQuienArranca() {
    Utiles::limpiarPantalla();
    cout << "Arranca JUGADOR " << jugadores[0]->getNumeroJugador()
         << ": que es el jefe de los " << jugadores[0]->getBando() << endl << endl;
}

void Simulacion::mostrarDeQuienEsTurno(int indiceJugadorActual) {
    cout << endl << "ES El TURNO DEL JUGADOR " << jugadores[indiceJugadorActual]->getNumeroJugador() <<
                    ", Jefe de los " << jugadores[indiceJugadorActual]->getBando() << endl;
}

void Simulacion::comenzarSimulacion(bool seMuestraMensajeGuardar, bool &seGuardaPartida,bool &finalDeJuego) {

    Ser* personaje;
    bool finalSimulacion = false;
    int i,j;
    int* vectorIDs;
    string bandoGanador;
    int numeroGanador;

    while (!finalSimulacion){
        i = 0;
        while (!finalSimulacion && i<2) { //Cada repeticion sería un turno de un solo jugador
            mostrarDeQuienEsTurno(i);
            permitirGuardarPartida(i, seMuestraMensajeGuardar,finalSimulacion,seGuardaPartida);
            if (!finalSimulacion) {
                vectorIDs = jugadores[i]->getVectorIDs();
                j = 0;
                while (!finalSimulacion && j < jugadores[i]->getCantidadPersonajes() ){
                    personaje = dynamic_cast<Ser *>(personajes->getDato(vectorIDs[j]));
                    interactuarPersonaje(personaje);
                    personaje->recargarEnergiaPorTurno();
                    eliminarMuertosEquipoContrario(i);
                    finalSimulacion = jugadores[0]->jugadorMuerto() || jugadores[1]->jugadorMuerto();
                    j++;
                }
                accionesSegundoPlano(i);
            }
            if (finalSimulacion && !seGuardaPartida){
                numeroGanador = jugadores[i]->getNumeroJugador();
                bandoGanador = jugadores[i]->getBando();
            }
            i++;
            seMuestraMensajeGuardar = true;
        }
    }
    Utiles::limpiarPantalla();
    if (!seGuardaPartida) {
        Utiles::eliminarArchivo(ARCHIVO_CARGAR_PARTIDA);
        ImpresionesPantalla::impresionGameOver();
        Utiles::dormir(1);
        cout << endl << "\nHa ganado el jugador " << numeroGanador << ", Jefe de los " << bandoGanador << "!!!" << endl;
        Utiles::dormir(4);
        finalDeJuego = true;
    }
}

void Simulacion::eliminarPersonaje(Ser *personaje, int indiceJugador) {
    jugadores[indiceJugador]->eliminarPersonajeVectorID(personaje);
    tablero->eliminarObjeto(personaje->obtenerFila()+1,personaje->obtenerColumna()+1);
}

void Simulacion::cargarIDsNuevaPartida() {
    setCantidadPorJugador();
    jugadores[0]->setVectorIDs();
    jugadores[1]->setVectorIDs();
    recorrerTableroNuevaPartida();
}

void Simulacion::recorrerTableroNuevaPartida() {
    jugadores[0]->recorrerTableroNuevaPartida();
    jugadores[1]->recorrerTableroNuevaPartida();
}

void Simulacion::setCantidadPorJugador() {
    if (jugadores[0]->getBando() == BANDO_MONSTRUOS) {
        jugadores[0]->setCantidadPersonajes(Monstruo::devolverCantidadMonstruos());
        jugadores[1]->setCantidadPersonajes(Humano::devolverCantidadHumanos());
    } else {
        jugadores[0]->setCantidadPersonajes(Humano::devolverCantidadHumanos());
        jugadores[1]->setCantidadPersonajes(Monstruo::devolverCantidadMonstruos());
    }
}

void Simulacion::elegirBando() {
    cout << "- JUGADOR 1 - Ingrese el bando:" << endl;
    cout << "1. Humanos\n2. Monstruos" << endl;
    string input;
    cin >> input;
    int opcionBando = Utiles::ingresoValido(input, 1, 2);
    procesarBando(opcionBando);
}

void Simulacion::setPersonajeBando(int id, const string &bando) {
    if (jugadores[0]->getBando() == bando) {
        jugadores[0]->setPersonaje(id);
    } else {
        jugadores[1]->setPersonaje(id);
    }
}

void Simulacion::procesarBando(int opcionBando) { //Esto procesa la opcion
    if (opcionBando == HUMANOS) {
        jugadores[0]->setBando(BANDO_HUMANOS);
        jugadores[1]->setBando(BANDO_MONSTRUOS);
    } else {
        jugadores[0]->setBando(BANDO_MONSTRUOS);
        jugadores[1]->setBando(BANDO_HUMANOS);
    }
}

void Simulacion::buscarPersonajePorID() {
    ImpresionesPantalla::impresionTituloBusquedaID();
    int id = ingresarID();
    cout << endl;
    bool encontrado = this->personajes->buscar(id);
    if (encontrado)
        this->personajes->getDato(id)->mostrar();
    else
        cout << "\nNo se encontro el objeto buscado con ID: " << id << endl;
}


int Simulacion::ingresarMenuSimulacion() {
    string opcion;
    ImpresionesPantalla::impresionMenuSimulacion();
    cin >> opcion;
    cout << endl;
    cout << endl;
    return Utiles::ingresoValido(opcion, BUSCAR_POR_ID, OPCION_MAXIMA_MENU_SIMULACION);
}

int Simulacion::ingresarID() {
    cout << "Ingrese el ID a buscar: ";
    string idIngresado;
    cin >> idIngresado;
    return Utiles::ingresoValido(idIngresado, 0, 999);
}

Jugador *Simulacion::getJugador(int indiceJugador) {
    Jugador *jugador = jugadores[indiceJugador];
    return jugador;
}

void Simulacion::setDiccionario(Arbol *diccionario) {
    this->personajes = diccionario;
}

void Simulacion::setNombreJugador(int numeroJugador, int indiceJugador) {
    this->jugadores[indiceJugador]->setNumeroJugador(numeroJugador);
}

void Simulacion::setBando(const string &nuevoBando, int indiceJugador) {
    this->jugadores[indiceJugador]->setBando(nuevoBando);
}

void Simulacion::cargarCantidadPersonajes(int numeroJugador, int cantidadPersonajes) {
    jugadores[numeroJugador]->setCantidadPersonajes(cantidadPersonajes);
}

void Simulacion::setTablero(Tablero *tablero) {
    this->tablero = tablero;
}

//------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------GUARDADO---------------------------------------------------------

void Simulacion::permitirGuardarPartida(int indiceJugadorActual, bool &seMuestraMensajeGuardar, bool &finalSimulacion, bool &seGuardaPartida) {
    if (seMuestraMensajeGuardar) {
        cout << "Desea guardar la partida? \n1. Si \t2.No" << endl;
        string ingreso;
        cin >> ingreso;
        if (Utiles::ingresoValido(ingreso, 1, 2) == 1) {
            guardarPartida(indiceJugadorActual);
            finalSimulacion = true;
            seGuardaPartida = true;
        }
    }
    seMuestraMensajeGuardar = false;
}

void Simulacion::guardarPartida(int indiceJugadorActual) {
    Utiles::eliminarArchivo(ARCHIVO_CARGAR_PARTIDA);
    EscrituraArchivo archivoPartida(ARCHIVO_CARGAR_PARTIDA);
    archivoPartida.escribirUltimaPalabraLinea(jugadores[indiceJugadorActual]->getNumeroJugador());
    archivoPartida.escribirFinLinea();
    int indiceJugadorContrario = jugadores[indiceJugadorActual]->obtenerIndiceJugadorContrario(indiceJugadorActual);
    guardarDatosJugador(archivoPartida, indiceJugadorActual);
    guardarDatosJugador(archivoPartida, indiceJugadorContrario);
    guardarDatosItems(archivoPartida);
    archivoPartida.cerrarArchivo();
}

void Simulacion::guardarDatosJugador(EscrituraArchivo &archivoPartida, int numeroJugador) {
    archivoPartida.escribir(getJugador(numeroJugador)->getBando());
    archivoPartida.escribirUltimaPalabraLinea(getJugador(numeroJugador)->getCantidadPersonajes());
    archivoPartida.escribirFinLinea();

    for (int i = 0; i < getJugador(numeroJugador)->getCantidadPersonajes(); i++) {
        Ser* personaje = dynamic_cast<Ser *>(personajes->getDato(getJugador(numeroJugador)->getVectorIDs()[i]));
        archivoPartida.escribir(Utiles::obtenerNombreObjeto(personaje->obtenerNombreMapa()));
        archivoPartida.escribirID(personaje->obtenerID());
        archivoPartida.escribir(personaje->obtenerArmadura());
        archivoPartida.escribir(personaje->obtenerFuerza());
        archivoPartida.escribir(personaje->obtenerVida());
        archivoPartida.escribir(personaje->obtenerEnergia());
        archivoPartida.escribir(personaje->obtenerFila() + 1);
        archivoPartida.escribir(personaje->obtenerColumna()+ 1);

        archivoPartida.escribir(personaje->getInventario()->getAguaBendita());
        archivoPartida.escribir(personaje->getInventario()->getCruz());
        archivoPartida.escribir(personaje->getInventario()->getEstaca());
        archivoPartida.escribir(personaje->getInventario()->getEscopeta());
        archivoPartida.escribirUltimaPalabraLinea(personaje->getInventario()->getBala());
        archivoPartida.escribirFinLinea();
    }
}

void Simulacion::guardarDatosItems(EscrituraArchivo &archivoPartida) {
    int f = 1, c , cantidadItemsGuardados = 0;
    int cantidadItems = Elemento::devolverCantidadElementos();
    archivoPartida.escribir(ITEMS);
    archivoPartida.escribirUltimaPalabraLinea(cantidadItems);
    while ( f <= tablero->getAlto() && cantidadItemsGuardados < cantidadItems) {
        c = 1;
        while ( c <= tablero->getAlto() && cantidadItemsGuardados < cantidadItems){
            if (tablero->devolverCasillero(f,c)->tieneItem()){
                archivoPartida.escribirFinLinea();
                Elemento* item = dynamic_cast<Elemento *>(tablero->devolverCasillero(f,c)->devolverItem());
                archivoPartida.escribir(Utiles::obtenerNombreObjeto(item->obtenerNombreMapa()));
                archivoPartida.escribirID(item->obtenerID());
                archivoPartida.escribir(item->devolverCantidad());
                archivoPartida.escribir(item->obtenerFila() + 1);
                archivoPartida.escribirUltimaPalabraLinea(item->obtenerColumna()+ 1);
                cantidadItemsGuardados++;
            }
            c++;
        }
        f++;
    }
}

//------------------------------------------------------------------------------------------------------------------
//----------------------------------------INTERACCION PERSONAJE-----------------------------------------------------

void Simulacion::interactuarPersonaje(Ser *personaje) {
    Accion accion = ES_REALIZABLE;
    ITEM_ELEGIDO armaElegida = NINGUNO;
    int opcionIngresada = 0;
    bool ejecucionExitosa = false;

    while (opcionIngresada != PASAR && !ejecucionExitosa) {
        Utiles::limpiarPantalla();


        opcionIngresada = mostrarMenuPersonaje(personaje);

        switch (opcionIngresada) {
            case ATACAR:
                atacar(personaje,ejecucionExitosa);
                Utiles::botonContinuar();
                Utiles::limpiarPantalla();
                break;
            case DEFENDER:
                defender(personaje,ejecucionExitosa);
                Utiles::botonContinuar();
                Utiles::limpiarPantalla();
                break;
            case MOVER:
                movimientos->moverPersonaje(personaje,ejecucionExitosa);
                ImpresionesPantalla::impresionBotonContinuar();
                break;
            case PASAR:
                ImpresionesPantalla::impresionBotonContinuar();
            default:
                break;
        }
        Utiles::limpiarPantalla();

    }
}

int Simulacion::mostrarMenuPersonaje(Ser *personaje) {
    personaje->mostrar();
    Gotoxy gotox;
    cout << "╔════════════════════════════════════════╗" << endl;
    cout << "║" << setfill(' ') << setw(28) << "MENU DE PERSONAJE" << setfill(' ') << setw(15) << "║" << endl;
    cout << "║" << setfill(' ') << setw(43) << "║" << endl;
    cout << "║" << setfill(' ') << setw(23) << "1. Atacar" << setfill(' ') << setw(20) << "║" << endl;
    cout << "║" << setfill(' ') << setw(43) << "║" << endl;
    cout << "║" << setfill(' ') << setw(25) << "2. Defender" << setfill(' ') << setw(18) << "║" << endl;
    cout << "║" << setfill(' ') << setw(43) << "║" << endl;
    cout << "║" << setfill(' ') << setw(22) << "3. Mover" << setfill(' ') << setw(21) << "║" << endl;
    cout << "║" << setfill(' ') << setw(43) << "║" << endl;
    cout << "║" << setfill(' ') << setw(22) << "4. Pasar" << setfill(' ') << setw(21) << "║" << endl;
    cout << "╚════════════════════════════════════════╝"<<endl;
    tablero->mostrar();
    cout <<gotox.pos(32, 2)<<"Ingrese una opcion: ";
    string accion;
    cin >> accion;
    int opcionIngresada = Utiles::ingresoValido(accion, 1, 4);
    return opcionIngresada;
}

//-----------------------------------------------------------------------------------//
//--------------------------------------- ATAQUE-------------------------------------//


void Simulacion::atacar(Ser* atacante, bool &ejecucionExitosa) {
    Accion accion = ES_REALIZABLE;
    ITEM_ELEGIDO armaElegida;
    int filaElegida,columnaElegida;
    int filaAtacante = atacante->obtenerFila()+1;
    int columnaAtacante = atacante->obtenerColumna()+1;
    Ser* atacado;

    if (atacante->tieneEnergiaAtaque(accion) && atacante->elegirArma(accion,armaElegida) &&
        rangos->estaEnRango(filaAtacante,columnaAtacante,filaElegida,columnaElegida,ATAQUE,accion,armaElegida,atacante)
        && tablero->hayQuienAtacarDefender(atacante, accion, filaElegida, columnaElegida,ATAQUE)){

        atacado = dynamic_cast<Ser *>(tablero->devolverCasillero(filaElegida,columnaElegida)->devolverSer());

        //Si la accion es realizable, se ejecuta atacar de las clases de los personajes
        //Luego hay otra funcion que se llama atacado donde se realiza el golpe del otro lado

        atacante->atacar(armaElegida);
        atacado->recibeAtaque(atacante,armaElegida);

        ejecucionExitosa = true;
    } else {
        Utiles::mostrarError(accion);
    }
}

//-----------------------------------------------------------------------------------//
//---------------------------------- DEFENSA ----------------------------------------//

void Simulacion::defender(Ser *defensor, bool &ejecucionExitosa) {
    Accion accion = ES_REALIZABLE;
    ejecucionExitosa = true;

    if (defensor->tieneEnergiaDefensa(accion)){
        defensor->elegirDefensa();
        DEFENSA_ELEGIDA defensaElegida = defensor->obtenerDefensa();

        if (defensaElegida == DEFENSA_NOSFERATU || defensaElegida == DEFENSA_CAZADOR_CURAR_EQUIPO ||
            defensaElegida == DEFENSA_CURAR_VANESA) {
            defensaEspecial(defensor,accion);
        } else {
            defensor->defender();
        }
    }

    if (accion != ES_REALIZABLE) {
        Utiles::mostrarError(accion);
        ejecucionExitosa = false;
    }
}


void Simulacion::defensaEspecial(Ser *defensor, Accion &error) {
    DEFENSA_ELEGIDA defensaElegida = defensor->obtenerDefensa();
    int filaDefensor = defensor->obtenerFila()+1;
    int columnaDefensor = defensor->obtenerColumna()+1;
    int filaElegida,columnaElegida;

    if ( (defensaElegida == DEFENSA_NOSFERATU || defensaElegida == DEFENSA_CURAR_VANESA) &&
          rangos->estaEnRango(filaDefensor,columnaDefensor,filaElegida,columnaElegida,DEFENSA,error,NINGUNO,defensor) &&
          tablero->hayQuienAtacarDefender(defensor,error,filaElegida,columnaElegida,DEFENSA)) {

        defensaNosferatuVanesa(filaElegida,columnaElegida, defensor, error);

    } else if (defensaElegida == DEFENSA_CAZADOR_CURAR_EQUIPO){
        int indiceBandoHumanos = obtenerIndiceBando(BANDO_HUMANOS);
        if (!cazadorEstaSolo(indiceBandoHumanos)) {
            cazadorCuraEquipo(defensor, error,indiceBandoHumanos);
        } else {
            error = CAZADOR_ESTA_SOLO_EN_EQUIPO;
        }
    }

}

void Simulacion::defensaNosferatuVanesa(int filaElegida, int columnaElegida, Ser *defensor, Accion &error) {
    if (defensor->esNosferatu()){
        Vampiro* victimaNosferatu = dynamic_cast<Vampiro *>(tablero->devolverCasillero(filaElegida, columnaElegida)->devolverSer());
        if (victimaNosferatu->obtenerVida() > defensor->obtenerVida()) {
            defensaNosferatu(defensor, error, victimaNosferatu);
        } else {
            error = NOSFERATU_QUIERE_INTERCAMBIAR_CON_MENOR_VIDA;
        }
    } else {
        Humano* salvado = dynamic_cast<Humano *>(tablero->devolverCasillero(filaElegida, columnaElegida)->devolverSer());
        if (salvado->convertidoEnZombi()) {
            defensaVanesa(error, salvado);
        }
        else {
            error = VANESA_NO_EVITA_CONVERSION_DE_UN_SANO;
        }
    }
}

void Simulacion::defensaNosferatu(Ser *nosferatu, Accion &error, Vampiro *victimaNosferatu) {
    int vidaNosferatu = nosferatu->obtenerVida();
    int vidaVampiro = victimaNosferatu->obtenerVida();
    nosferatu->setVida(vidaVampiro);
    victimaNosferatu->setVida(vidaNosferatu);
    cout << "Nosferatu intercambio sus " << vidaNosferatu << " puntos de vida por los " << vidaVampiro << " puntos de vida del vampiro" << endl;
}

void Simulacion::defensaVanesa(Accion &error, Humano *salvado) {

    string nombreSalvado;
    salvado->seEvitoLaConversionZombi();
    if (salvado->esHumanoSimple()){
        nombreSalvado = NOMBRE_HUMANO;
    } else {
        nombreSalvado = "cazador";
    }
    cout << "Vanesa Van Helsing, Reina escupe fuego, ha evitado la conversión zombi del " << nombreSalvado << "! " << endl;
}

void Simulacion::cazadorCuraEquipo(Ser *defensor, Accion &error,int indiceBandoHumanos ) {
    Ser *humano;
    int idCazador = defensor->obtenerID();
    int *equipoHumanos = jugadores[indiceBandoHumanos]->getVectorIDs();
    int cantidadHumanos = jugadores[indiceBandoHumanos]->getCantidadPersonajes();

    for (int i = 0; i < cantidadHumanos; i++) {
        if (equipoHumanos[i] != idCazador) {
            humano = dynamic_cast<Ser *>(personajes->getDato(equipoHumanos[i]));
            humano->aumentarVida(20);
        }
    }
    equipoHumanos = nullptr;
    cout << "El cazador ha curado a los otros " << cantidadHumanos-1 << " miembros del bando de los humanos!" << endl;
}

int Simulacion::obtenerIndiceBando(string bandoRequerido) {
    int indiceBandoHumanos;
    if (jugadores[0]->getBando() == bandoRequerido) {
        indiceBandoHumanos = 0;
    } else {
        indiceBandoHumanos = 1;
    }
    return indiceBandoHumanos;
}

bool Simulacion::cazadorEstaSolo(int indiceBandoHumanos) {
    return (jugadores[indiceBandoHumanos]->getCantidadPersonajes() == 1);
}

//------------------------------------------------------------------------------------//
//----------------------ACCIONES EN SEGUNDO PLANO-------------------------------------//

void Simulacion::accionesSegundoPlano(int indiceDeQuienJugoRecien) {
    int indiceJugadorContrario = jugadores[indiceDeQuienJugoRecien]->obtenerIndiceJugadorContrario(indiceDeQuienJugoRecien);

    cancelarDefensasDeAtaques(indiceJugadorContrario);

    if (jugadores[indiceDeQuienJugoRecien]->getBando() == BANDO_MONSTRUOS){
        revisarConversionesZombiVampiro(indiceJugadorContrario);
    }
}

void Simulacion::cancelarDefensasDeAtaques(int indiceJugadorContrario) {
    int* vectorIDs = jugadores[indiceJugadorContrario]->getVectorIDs();
    int cantidadPersonajes = jugadores[indiceJugadorContrario]->getCantidadPersonajes();
    Ser* personaje;

    for (int i = cantidadPersonajes-1 ; i >= 0 ; i--) {
        personaje = dynamic_cast<Ser *>( personajes->getDato(vectorIDs[i]) );
        if (personaje->seEstaDefendiendoDelAtaque()) {
            personaje->seTerminoLaDefensa();
            vectorIDs = jugadores[indiceJugadorContrario]->getVectorIDs();
        }
    }
}

void Simulacion::eliminarMuertosEquipoContrario(int indiceDeQuienJugoRecien) {
    int indiceJugadorContrario = jugadores[indiceDeQuienJugoRecien]->obtenerIndiceJugadorContrario(indiceDeQuienJugoRecien);
    int* vectorIDs = jugadores[indiceJugadorContrario]->getVectorIDs();
    int cantidadPersonajes = jugadores[indiceJugadorContrario]->getCantidadPersonajes();
    Ser* personaje;
    for (int i = cantidadPersonajes-1 ; i >= 0 ; i--) {
        personaje = dynamic_cast<Ser *>( personajes->getDato(vectorIDs[i]) );
        if (!personaje->estaVivo()) {
            if (personaje->esMonstruo() || !( dynamic_cast<Humano *>(personaje)->convertidoEnZombi() || dynamic_cast<Humano *>(personaje)->convertidoEnVampiro() ) ){
                eliminarPersonaje(personaje, indiceJugadorContrario);
                cout << endl << "Ha habido una baja en el bando de los " << jugadores[indiceJugadorContrario]->getBando() << "! " << endl;
                Utiles::dormir(3);
            }
        }
    }
    jugadores[indiceDeQuienJugoRecien]->imprimirVectorIDS();
    jugadores[indiceJugadorContrario]->imprimirVectorIDS();
}


void Simulacion::revisarConversionesZombiVampiro(int indiceJugadorHumanos) {
    int* vectorIDs = jugadores[indiceJugadorHumanos]->getVectorIDs();
    int cantidadHumanos = jugadores[indiceJugadorHumanos]->getCantidadPersonajes();
    Humano* personaje;
    for (int i = cantidadHumanos-1 ; i >= 0 ; i--) {
        personaje = dynamic_cast<Humano *>( personajes->getDato(vectorIDs[i]));
        if (personaje->convertidoEnVampiro()) {
            conversionVampiro(personaje, indiceJugadorHumanos);
            vectorIDs = jugadores[indiceJugadorHumanos]->getVectorIDs();
            cantidadHumanos = jugadores[indiceJugadorHumanos]->getCantidadPersonajes();
        } else if (personaje->convertidoEnZombi()) {
            if (!personaje->seConvierteEnZombiAhora())
                personaje->esperarConversionZombi();
            else {
                conversionZombi(personaje, indiceJugadorHumanos);
                vectorIDs = jugadores[indiceJugadorHumanos]->getVectorIDs();
                cantidadHumanos = jugadores[indiceJugadorHumanos]->getCantidadPersonajes();
            }
        }
    }
    jugadores[indiceJugadorHumanos]->imprimirVectorIDS();
    jugadores[(jugadores[indiceJugadorHumanos]->obtenerIndiceJugadorContrario(indiceJugadorHumanos))]->imprimirVectorIDS();
}

void Simulacion::conversionVampiro(Humano *humano, int indiceJugadorHumanos) {
    int indiceJugadorMonstruos = jugadores[indiceJugadorHumanos]->obtenerIndiceJugadorContrario(indiceJugadorHumanos);
    int filaVampiro = humano->obtenerFila()+1;
    int columnaVampiro = humano->obtenerColumna()+1;
    int id = humano->obtenerID();
    float armadura = humano->obtenerArmadura();
    float fuerza = humano->obtenerFuerza();
    float vida = humano->obtenerVida();
    float energia = humano->obtenerEnergia();
    jugadores[indiceJugadorMonstruos]->agregarPersonajeVectorIDs(humano);
    eliminarPersonaje(dynamic_cast<Ser *>(humano),indiceJugadorHumanos); //Elimina del arbol y del tablero
    tablero->agregarObjeto(NOMBRE_VAMPIRO,filaVampiro,columnaVampiro,1,id);
    Casillero* casillero = tablero->devolverCasillero(filaVampiro,columnaVampiro);
    dynamic_cast<Ser *>(casillero->devolverSer())->setAtributos(vida,fuerza,armadura,energia);

    jugadores[indiceJugadorHumanos]->imprimirVectorIDS();
    jugadores[(jugadores[indiceJugadorHumanos]->obtenerIndiceJugadorContrario(indiceJugadorHumanos))]->imprimirVectorIDS();
}

void Simulacion::conversionZombi(Humano *humano, int indiceJugadorHumanos) {
    int indiceJugadorMonstruos = jugadores[indiceJugadorHumanos]->obtenerIndiceJugadorContrario(indiceJugadorHumanos);
    int filaZombi = humano->obtenerFila()+1;
    int columnaZombi = humano->obtenerColumna()+1;
    int id = humano->obtenerID();
    float armadura = humano->obtenerArmadura();
    float fuerza = humano->obtenerFuerza();
    float vida = humano->obtenerVida();
    float energia = humano->obtenerEnergia();
    unsigned int cantidadAguaBendita = humano->getInventario()->getAguaBendita();
    jugadores[indiceJugadorMonstruos]->agregarPersonajeVectorIDs(humano);
    eliminarPersonaje(dynamic_cast<Ser *>(humano),indiceJugadorHumanos);
    tablero->agregarObjeto(NOMBRE_ZOMBI,filaZombi,columnaZombi,1,id);
    Casillero* casillero = tablero->devolverCasillero(filaZombi,columnaZombi);
    dynamic_cast<Ser *>(casillero->devolverSer())->setAtributos(vida,fuerza,armadura,energia);
    dynamic_cast<Ser *>(casillero->devolverSer())->getInventario()->setAguaBendita(cantidadAguaBendita);
}

Simulacion::~Simulacion() {
    delete jugadores[0];
    delete jugadores[1];
    delete movimientos;
    delete rangos;
}