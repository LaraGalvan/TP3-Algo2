#include "Ser.h"
#include "Escopeta.h"
#include "Constantes.h"

Ser::Ser(int id, int fila, int columna) : Objeto(id, fila, columna) {
    this->energia = (float) Utiles::buscarNumeroAleatorio(0, 20);
    this->vida = (float) Utiles::buscarNumeroAleatorio(20, 100);
    this->armadura = (float) Utiles::buscarNumeroAleatorio(0, 2);
    this->fuerza = (float) Utiles::buscarNumeroAleatorio(10,40);
    this->inventario = new Inventario;
    energiaMinimaDefensa = 0;
    seDefiendeDelAtaque = false;
}

void Ser::mostrarAtributos() {
	cout << "\nATRIBUTOS" << endl;
	cout << "Energia: " << this->energia << endl;
	cout << "Vida: " << this->vida << endl;
	cout << "Armadura: " << this->armadura << endl;
	cout << "Fuerza: " << this->fuerza << endl;
	cout << endl;
	cout << "COORDENADAS" << endl;
	cout << "FILA: " << fila+1 << endl;
	cout << "COLUMNA: " << columna+1 << endl;
	cout << endl;
}

float Ser::proteccionArmaduraAtaque() {
    float porcentajeAtaqueConArmadura;
    if (!armadura) {
        porcentajeAtaqueConArmadura = 1;
    } else if (armadura == 1) {
        porcentajeAtaqueConArmadura = 0.9;
    } else if (armadura == 2) {
        porcentajeAtaqueConArmadura = 0.8;
    } else { //armadura > 2
        porcentajeAtaqueConArmadura = 0.2;
    }
    return porcentajeAtaqueConArmadura;
}

bool Ser::tieneEnergiaAtaque(Accion &error) {
    bool tieneEnergia;
    if (this->energia >= this->energiaMinimaAtaque) {
        tieneEnergia = true;
    } else {
        tieneEnergia = false;
        error = SIN_ENERGIA_ATAQUE;
    }
    return (tieneEnergia);
}

DEFENSA_ELEGIDA Ser::obtenerDefensa() {
    return defensaElegida;
}

bool Ser::tieneEnergiaDefensa(Accion &error) {
    bool tieneSuficienteEnergia;
    if (this->energia >= this->energiaMinimaDefensa) {
        tieneSuficienteEnergia = true;
    } else {
        tieneSuficienteEnergia = false;
        error = SIN_ENERGIA_DEFENSA;
    }
    return (tieneSuficienteEnergia);
}

bool Ser::seEstaDefendiendoDelAtaque() {
    return seDefiendeDelAtaque;
}

void Ser::seTerminoLaDefensa() {
    seDefiendeDelAtaque = false;
}


void Ser::recargarEnergiaPorTurno() {
    this->energia = (this->energia + this->recargaEnergiaTurno);
    correcionLimiteEnergia();
}

void Ser::correcionLimiteEnergia() {
    if(energia < 0) {
        energia = 0;
    }
    else if(energia > 20){
        energia = 20;
    }
}

void Ser::correcionLimiteVida() {
    if(vida < 0){
        vida = 0;
    } else if(vida > 100){
        vida = 100;
    }
}


float Ser::obtenerVida() {
    return vida;
}

float Ser::obtenerEnergia() {
    return energia;
}

float Ser::obtenerArmadura() {
    return armadura;
}

float Ser::obtenerFuerza() {
    return fuerza;
}

void Ser::setVida(float nuevaVida) {
    this->vida = nuevaVida;
    correcionLimiteVida();
}

void Ser::aumentarVida(float cantidad) {
    this->vida = (this->vida + cantidad);
    correcionLimiteVida();
}

void Ser::disminuirVida(float cantidad) {
    this->vida = (this->vida - cantidad);
    correcionLimiteVida();
}

void Ser::setEnergia(float nuevaEnergia) {
    this->energia = nuevaEnergia;
    correcionLimiteEnergia();
}

void Ser::aumentarEnergia(int aumentoEnergia){
    this->energia = (this->energia + aumentoEnergia);
    correcionLimiteEnergia();
}
void Ser::disminuirEnergia(int energiaConsumida) {
    this->energia = (this->energia - energiaConsumida);
    correcionLimiteEnergia();
}

void Ser::setArmadura(float nuevaArmadura) {
    this->armadura = nuevaArmadura;
}

void Ser::aumentarArmadura(float aumentoArmadura){
    this->armadura = (this->armadura + aumentoArmadura);
}

void Ser::disminuirArmadura(float armaduraPerdida){
    this->armadura = (this->armadura - armaduraPerdida);

}

void Ser::setFuerza(float nuevaFuerza) {
    this->fuerza = nuevaFuerza;

}

void Ser::setInventario(Inventario *inventario) {
    this->inventario = inventario;
}

void Ser::guardarEnInventario(unsigned int cantAgua, unsigned int cantCruces, unsigned int cantEstacas,unsigned int cantBalas, bool tieneEscopeta) {
    inventario->setCruz(cantCruces);
    inventario->setEstaca(cantEstacas);
    inventario->setAguaBendita(cantAgua);
    inventario->setBala(cantBalas);
    if (tieneEscopeta)
        inventario->setEscopeta();
}

void Ser::setAtributos(float nuevaVida, float nuevaFuerza, float nuevaArmadura, float nuevaEnergia) {
    this->vida = nuevaVida;
    this->fuerza = nuevaFuerza;
    this->armadura = nuevaArmadura;
    this->energia = nuevaEnergia;
}

Inventario* Ser::getInventario() {
    return this->inventario;
}

bool Ser::estaVivo() {
    return (vida > 0);
}

bool Ser::esHumano() {
    return (obtenerNombreMapa() == LETRA_VANESA || obtenerNombreMapa() == LETRA_HUMANO || obtenerNombreMapa() == LETRA_CV );

}

bool Ser::esZombi(){
    return obtenerNombreMapa() == LETRA_ZOMBI;
}

bool Ser::esVampiroGeneral() {
    return (obtenerNombreMapa() == LETRA_NOSFERATU || obtenerNombreMapa() == LETRA_VAMPIRO || obtenerNombreMapa() == LETRA_VAMPIRELLA);
}

bool Ser::esVampiro() {
    return obtenerNombreMapa() == LETRA_VAMPIRO;
}

bool Ser::esVampirella(){
    return obtenerNombreMapa() == LETRA_VAMPIRELLA;

}

bool Ser::esNosferatu() {
    return obtenerNombreMapa() == LETRA_NOSFERATU;

}

bool Ser::esMonstruo(){
    return (obtenerNombreMapa() == LETRA_NOSFERATU || obtenerNombreMapa() == LETRA_VAMPIRO ||
            obtenerNombreMapa() == LETRA_VAMPIRELLA || obtenerNombreMapa() == LETRA_ZOMBI);
}

bool Ser::esHumanoSimple() {
    return obtenerNombreMapa() == LETRA_HUMANO;
}

bool Ser::esCazadorGeneral() {
    return (obtenerNombreMapa() == LETRA_CV || obtenerNombreMapa() == LETRA_VANESA);
}

bool Ser::esCazador() {
    return obtenerNombreMapa() == LETRA_CV;
}

bool Ser::esVanesa(){
    return obtenerNombreMapa() ==  LETRA_VANESA;
}

void Ser::mostrar() { }

Ser::~Ser() {
    delete inventario;
}
