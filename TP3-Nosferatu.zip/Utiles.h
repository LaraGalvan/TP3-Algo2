#ifndef TP3_NOSFERATU_UTILES_H
#define TP3_NOSFERATU_UTILES_H

#include <cstdlib>
#include <ctime>
#include <iostream>

#ifdef __linux__
#define LIMPIAR "clear"
#endif // __linux__

#ifdef __MINGW32__
#define LIMPIAR "CLS"
#endif // __MINGW32__

using namespace std;


enum Accion {
    ES_REALIZABLE,
    SIN_ENERGIA_ATAQUE,
    SIN_ENERGIA_DEFENSA,
    SIN_BALAS_SUFICIENTES,
    POSICION_FUERA_RANGO,
    MISMO_CASILLERO_QUE_ATACANTE,
    NO_HAY_ESCOPETA_EN_INVENTARIO,
    NO_HAY_AGUA_EN_INVENTARIO,
    NO_HAY_QUIEN_SANAR,
    NO_HAY_CON_QUIEN_INTERCAMBIAR,
    NO_HAY_NADIE_DEFENSA,
    INVENTARIO_VACIO,
    NO_HAY_A_QUIEN_ATACAR,
    ES_DE_MISMO_BANDO,
    ZOMBI_NO_TIENE_QUIEN_ATACAR_ALEATORIAMENTE,
    CAZADOR_ESTA_SOLO_EN_EQUIPO,
    VANESA_NO_EVITA_CONVERSION_DE_UN_SANO,
    NOSFERATU_QUIERE_INTERCAMBIAR_CON_MENOR_VIDA,
    NO_PUEDE_MOVERSE_COSTO_INFINITO,
    SIN_ENERGIA_MOVERSE,
    MISMA_CASILLA_QUE_ESTOY_PARA_MOVERSE
};

class Utiles {
public:

    //PRE: Recibe un parametro minimo y maaximo de tipo entero
    //POST:Devuelve un numero aleatorio dentro del rango definido por "minimo" y "maximo"
    static int buscarNumeroAleatorio(int minimo, int maximo);

    //PRE: -
    //POST: Se llama a la funcion de la clase Utiles
    static void limpiarPantalla();

    //PRE: -
    //POST: Se muestra por pantalla un mensaje para presionar el boton continuar
    static void botonContinuar();

    //PRE: Recibe una variable del tipo string, un minimo y maximo de tipo entero
    //POST: Devuelve una opcion ingresada por el usuario ya validada
    static int ingresoValido(string input, int minimo, int maximo);

    //PRE: Recibe una variable del tipo string
    //POST: Devuelve true si el string ingresado es del tipo numerico
    static bool esStringNumerico(string input);

    //PRE: Recibe una opcion minima y maxima de tipo entero y una variable del tipo string
    //POST: Devuelve true si lo ingresado por el usuario es un numero valido
    static bool esNumeroValido(const string& ingreso, int opcionMinima, int opcionMaxima);

    //PRE: Recibe el nombre de un archivo del tipo string
    //POST: Devuelve true si el archivo pasado por parametro existe. False en caso contrario
    static bool archivoExistente(const string& nombreArchivo);

    static void dormir(int segundos);

    //PRE: Recibe la ficha de un objeto valida
    //POST: Devuelve el nombre del objeto
    static string obtenerNombreObjeto(char fichaObjeto);

    //PRE: Recibe el nombre de un archivo
    //POST: Elimina el archivo
    static void eliminarArchivo(const string& pathArchivo);

    //PRE:
    //POST: muestra cualquier error durante la simulacion
    static void mostrarError(Accion tipoError);

};


enum ITEM_ELEGIDO {
    ITEM_ESCOPETA = 1,
    ITEM_ESTACA = 2,
    ITEM_AGUA_BENDITA = 3,
    ITEM_CRUZ = 4,
    NINGUNO = 5,
    ITEM_BALA,
};

enum TIPO_ACCION {
    ATAQUE,
    DEFENSA
};

enum DEFENSA_ELEGIDA {
    DEFENSA_AGUA,
    DEFENSA_HUMANO_PUNTO_ARMADURA,
    DEFENSA_CRUZ,
    DEFENSA_NINGUN_ELEMENTO,
    DEFENSA_CAZADOR_CURAR_EQUIPO,
    DEFENSA_ZOMBI_BAJO_TIERRA,
    DEFENSA_CURAR_VANESA,
    DEFENSA_NOSFERATU
};





#endif //TP3_NOSFERATU_UTILES_H
