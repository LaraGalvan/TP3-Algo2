#ifndef CASILLEROLAGO_H_
#define CASILLEROLAGO_H_

#include "Casillero.h"

class CasilleroLago : public Casillero {
public:
    //constructor
    CasilleroLago(int fila, int columna);
};

#endif /* CASILLEROLAGO_H_ */
