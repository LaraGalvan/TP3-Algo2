#ifndef VANESA_H_
#define VANESA_H_

#include "Cazador.h"
#include <iostream>
using namespace std;

class Vanesa : public Cazador {

private:
    //atributos
    bool inmuneAtaqueVampirico;
    bool humanosProtegidos;



public:
    // Constructor
    Vanesa(int id, int fila, int columna);

    //PRE:
    //POST:imprime por pantalla las opciones de defensa y le da al usuario la opcion a elegir
    void elegirDefensa();

    //PRE: -
    //POST: se ejecuta la defensa correspondida al ser elegida por el usuario
    void defender();

    //PRE:
    //POST:imprime por pantalla su nombre, sus atributo y su ubicacion
    void mostrar() override;
};

#endif