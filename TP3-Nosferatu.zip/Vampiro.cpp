#include "Vampiro.h"
#include "Constantes.h"


Vampiro::Vampiro(int id, int fila, int columna) : Monstruo(id, fila, columna) {
	nombreMapa = LETRA_VAMPIRO;
	this->recargaEnergiaTurno = 4;
	this->energiaMinimaAtaque = 2;
	this->energiaMinimaDefensa = 4;
}

void Vampiro::atacar(ITEM_ELEGIDO arma) {
    disminuirEnergia(energiaMinimaAtaque);
}

void Vampiro::recibeAtaque(Ser* atacante, ITEM_ELEGIDO arma) {
    Humano* atacanteHumano = dynamic_cast<Humano *>(atacante);
    float vidaQuitada = 0;

    if (esVampiro() && seDefiendeDelAtaque) {
        armadura++;
    }
    if (atacanteHumano->esHumanoSimple()) {
        vidaQuitada = 0.2 * atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque();
    } else if (atacanteHumano->esCazador()) {
        if (arma == ITEM_ESCOPETA) {
            vidaQuitada = atacanteHumano->getPorcentajeAtaqueVampiro() * atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque();
        } else if (arma == ITEM_AGUA_BENDITA) {
            vidaQuitada = 10 * proteccionArmaduraAtaque();
        } else if (arma == ITEM_ESTACA && !(esVampirella() && seDefiendeDelAtaque)) {
            vidaQuitada = 60 * proteccionArmaduraAtaque();
        }
    } else if (atacanteHumano->esVanesa()) {
        if (arma == ITEM_ESCOPETA) {
            vidaQuitada = atacanteHumano->getPorcentajeAtaqueVampiro() * atacanteHumano->obtenerFuerza() * proteccionArmaduraAtaque();
        } else if (arma == ITEM_AGUA_BENDITA && !(esVampirella() && seDefiendeDelAtaque)) {
            vidaQuitada = 20 * proteccionArmaduraAtaque();
        } else if (arma == ITEM_ESTACA && !(esVampirella() && seDefiendeDelAtaque)) {
            setVida(0);
        }
    }
    if (! (atacanteHumano->esVanesa() && arma == ITEM_ESTACA) ) {
        disminuirVida( (int) vidaQuitada);
    }
    if (esVampiro() && seDefiendeDelAtaque) {
        armadura--;
    }
    mostrarAtaqueRecibido(atacante,arma,vidaQuitada);
}

void Vampiro::mostrarAtaqueRecibido(Ser *atacante, ITEM_ELEGIDO arma, int vidaQuitada) {
    string nombreAtacado, nombreArma;
    if (esVampiro()) {
        nombreAtacado = "l vampiro";
    } else if (esNosferatu()){
        nombreAtacado = " Nosferatu";
    } else {
        nombreAtacado = " Vampirella";
    }
    if (arma == ITEM_ESCOPETA) {
        nombreArma = "la escopeta";
    } else if (arma == ITEM_AGUA_BENDITA) {
        nombreArma = "el agua bendita";
    } else if (arma == ITEM_ESTACA) {
        nombreArma = "la estaca";
    }
    if (atacante->esVanesa() && arma != ITEM_ESCOPETA  && !(esVampirella() && seDefiendeDelAtaque)){
        cout << "Vanesa con su estaca antivampiros es increible!" << endl;
        cout << "A" << nombreAtacado << " no le alcanzo el tiempo para reaccionar! " << endl;
    } else if (arma != ITEM_ESCOPETA && esVampirella() && seDefiendeDelAtaque) {
        cout << "Vampirella se habia transformado en murciélago. Perdiste tu tiempo intentando atacarla con " << arma << "!" << endl;
    } else if (vidaQuitada){
        cout << "Le has sacado hasta " << vidaQuitada << " puntos de vida a" << nombreAtacado << " con " << nombreArma << endl;
    }
}


void Vampiro::elegirDefensa() {
    defensaElegida = DEFENSA_NINGUN_ELEMENTO;
    cout << endl << "El vampiro se ocultará en las sombras! Recibirá +1 armadura por un turno." << endl;
}

void Vampiro::defender() {
    seDefiendeDelAtaque = true;
}

void Vampiro::mostrar() {
    std::cout << "\n Soy Vampiro" << std::endl;
    mostrarAtributos();
}
